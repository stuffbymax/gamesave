---
layout: default
title: "LEGO Harry Potter: Years 1-4"
parent: PS3 Saves
permalink: PS3/BLES00720/
---
# LEGO Harry Potter: Years 1-4

## PS3 Saves - BLES00720

| Icon | Filename | Description |
|------|----------|-------------|
| ![LEGO Harry Potter: Years 1-4](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% complete save |
