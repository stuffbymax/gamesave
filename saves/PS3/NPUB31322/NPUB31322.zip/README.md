---
layout: default
title: "Dragon Ball Z: Battle of Z"
parent: PS3 Saves
permalink: PS3/NPUB31322/
---
# Dragon Ball Z: Battle of Z

## PS3 Saves - NPUB31322

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dragon Ball Z: Battle of Z](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | All Characters Unlocked, Story Mode Finished, All Game Objects Obtained |
