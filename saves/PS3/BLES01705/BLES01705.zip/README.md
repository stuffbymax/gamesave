---
layout: default
title: "BioShock Infinite"
parent: PS3 Saves
permalink: PS3/BLES01705/
---
# BioShock Infinite

## PS3 Saves - BLES01705

| Icon | Filename | Description |
|------|----------|-------------|
| ![BioShock Infinite](ICON0.PNG) | [00093826.zip](00093826.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Max Cash - Max Lockpicks. |
