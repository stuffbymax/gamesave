---
layout: default
title: "Naruto Shippuden - Ultimate Ninja Storm Generations"
parent: PS3 Saves
permalink: PS3/BLUS30792/
---
# Naruto Shippuden - Ultimate Ninja Storm Generations

## PS3 Saves - BLUS30792

| Icon | Filename | Description |
|------|----------|-------------|
| ![Naruto Shippuden - Ultimate Ninja Storm Generations](ICON0.PNG) | [00114210.zip](00114210.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheat added: Max Ryo. |
