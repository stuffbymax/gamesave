---
layout: default
title: "Dead Or Alive 5"
parent: PS3 Saves
permalink: PS3/NPEB01129/
---
# Dead Or Alive 5

## PS3 Saves - NPEB01129

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dead Or Alive 5](ICON0.PNG) | [00061307.zip](00061307.zip){: .btn .btn-purple } | All Characters And Costumes Unlocked |
