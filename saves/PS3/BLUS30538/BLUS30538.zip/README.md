---
layout: default
title: "Batman: Arkham City"
parent: PS3 Saves
permalink: PS3/BLUS30538/
---
# Batman: Arkham City

## PS3 Saves - BLUS30538

| Icon | Filename | Description |
|------|----------|-------------|
| ![Batman: Arkham City](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Batman Arkham City game save 100% complete on normal |
| ![Batman: Arkham City](ICON0.PNG) | [00122634.zip](00122634.zip){: .btn .btn-purple } | New Game+ (Requires all DLC). Completed Riddler Trophies. Max Upgrades. |
