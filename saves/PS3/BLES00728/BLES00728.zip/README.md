---
layout: default
title: "BioShock 2"
parent: PS3 Saves
permalink: PS3/BLES00728/
---
# BioShock 2

## PS3 Saves - BLES00728

| Icon | Filename | Description |
|------|----------|-------------|
| ![BioShock 2](ICON0.PNG) | [00093449.zip](00093449.zip){: .btn .btn-purple } | Virgin Save[0%]; Cheats added: Max Cash - Max Adam |
