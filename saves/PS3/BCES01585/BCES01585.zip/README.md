---
layout: default
title: "The Last Of Us"
parent: PS3 Saves
permalink: PS3/BCES01585/
---
# The Last Of Us

## PS3 Saves - BCES01585

| Icon | Filename | Description |
|------|----------|-------------|
| ![The Last Of Us](ICON0.PNG) | [00033539.zip](00033539.zip){: .btn .btn-purple } | New Game+ Max Skill & Weapons Upgrade Normal |
