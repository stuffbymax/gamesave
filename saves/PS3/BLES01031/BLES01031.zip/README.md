---
layout: default
title: "Call Of Duty Black Ops"
parent: PS3 Saves
permalink: PS3/BLES01031/
---
# Call Of Duty Black Ops

## PS3 Saves - BLES01031

| Icon | Filename | Description |
|------|----------|-------------|
| ![Call Of Duty Black Ops](ICON0.PNG) | [00001232.zip](00001232.zip){: .btn .btn-purple } | All missions beaten on Veteran difficulty, all intel found, Five and Dead Ops Arcade unlocked, 100% complete. |
