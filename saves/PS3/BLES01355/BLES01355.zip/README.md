---
layout: default
title: "ULTIMATE MARVEL VS. CAPCOM 3"
parent: PS3 Saves
permalink: PS3/BLES01355/
---
# ULTIMATE MARVEL VS. CAPCOM 3

## PS3 Saves - BLES01355

| Icon | Filename | Description |
|------|----------|-------------|
| ![ULTIMATE MARVEL VS. CAPCOM 3](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, all characters unlocked |
