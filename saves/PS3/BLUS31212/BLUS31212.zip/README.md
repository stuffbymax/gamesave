---
layout: default
title: "Kingdom Hearts HD 1.5 ReMIX"
parent: PS3 Saves
permalink: PS3/BLUS31212/
---
# Kingdom Hearts HD 1.5 ReMIX

## PS3 Saves - BLUS31212

| Icon | Filename | Description |
|------|----------|-------------|
| ![Kingdom Hearts HD 1.5 ReMIX](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Kingdom Hearts 1.5 Remix (Max Character Stats) |
| ![Kingdom Hearts HD 1.5 ReMIX](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | Kingdom Hearts Re: Chain of Memories (Map Cards 50 Cards Each) |
