---
layout: default
title: "YAKUZA: Dead Souls"
parent: PS3 Saves
permalink: PS3/BLUS30826/
---
# YAKUZA: Dead Souls

## PS3 Saves - BLUS30826

| Icon | Filename | Description |
|------|----------|-------------|
| ![YAKUZA: Dead Souls](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed (profile savedata to unlock new game plus options) |
| ![YAKUZA: Dead Souls](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | 100% completed savedata |
