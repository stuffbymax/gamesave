---
layout: default
title: "Borderlands"
parent: PS3 Saves
permalink: PS3/BLES00697/
---
# Borderlands

## PS3 Saves - BLES00697

| Icon | Filename | Description |
|------|----------|-------------|
| ![Borderlands](ICON0.PNG) | [00063120.zip](00063120.zip){: .btn .btn-purple } | Platinum Save |
| ![Borderlands](ICON0.PNG) | [00114653.zip](00114653.zip){: .btn .btn-purple } | starter save, max: xp,money,skill points |
