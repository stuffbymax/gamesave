---
layout: default
title: "YAKUZA 4"
parent: PS3 Saves
permalink: PS3/BLUS30643/
---
# YAKUZA 4

## PS3 Saves - BLUS30643

| Icon | Filename | Description |
|------|----------|-------------|
| ![YAKUZA 4](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | profile savedata to unlock new game plus options |
| ![YAKUZA 4](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | 100% completed, all secondary missions cleared |
