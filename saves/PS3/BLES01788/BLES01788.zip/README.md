---
layout: default
title: "Hyperdimension Neptunia Victory"
parent: PS3 Saves
permalink: PS3/BLES01788/
---
# Hyperdimension Neptunia Victory

## PS3 Saves - BLES01788

| Icon | Filename | Description |
|------|----------|-------------|
| ![Hyperdimension Neptunia Victory](ICON0.PNG) | [00013156.zip](00013156.zip){: .btn .btn-purple } | Virgin Save[0%]: Max Health except DLC characters Max Money Goddess and Cadets Max |
