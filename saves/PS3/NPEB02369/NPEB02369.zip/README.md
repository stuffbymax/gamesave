---
layout: default
title: "Grand Theft Auto: San Andreas"
parent: PS3 Saves
permalink: PS3/NPEB02369/
---
# Grand Theft Auto: San Andreas

## PS3 Saves - NPEB02369

| Icon | Filename | Description |
|------|----------|-------------|
| ![Grand Theft Auto: San Andreas](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Platinum Save, only 3 trophys rest (The police, ambulance and firefight missions) |
