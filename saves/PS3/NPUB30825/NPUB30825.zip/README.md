---
layout: default
title: "Far Cry 3"
parent: PS3 Saves
permalink: PS3/NPUB30825/
---
# Far Cry 3

## PS3 Saves - NPUB30825

| Icon | Filename | Description |
|------|----------|-------------|
| ![Far Cry 3](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | (Save and Profile)Everything unlocked, all main and secondary missions passed, all selectable weapons. |
