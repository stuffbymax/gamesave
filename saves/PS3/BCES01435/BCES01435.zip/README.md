---
layout: default
title: "PlayStation All Stars - Battle Royale"
parent: PS3 Saves
permalink: PS3/BCES01435/
---
# PlayStation All Stars - Battle Royale

## PS3 Saves - BCES01435

| Icon | Filename | Description |
|------|----------|-------------|
| ![PlayStation All Stars - Battle Royale](ICON0.PNG) | [00115333.zip](00115333.zip){: .btn .btn-purple } | All Profile-Backgrounds, Icons, Minions, Character-Costumes, Animations, Victory Music, Profile-FFA Titles, and Profile-Team Titles Unlock. Does not require DLC. |
