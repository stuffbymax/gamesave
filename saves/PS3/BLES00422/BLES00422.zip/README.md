---
layout: default
title: "Alone in the Dark: Inferno"
parent: PS3 Saves
permalink: PS3/BLES00422/
---
# Alone in the Dark: Inferno

## PS3 Saves - BLES00422

| Icon | Filename | Description |
|------|----------|-------------|
| ![Alone in the Dark: Inferno](ICON0.PNG) | [00000804.zip](00000804.zip){: .btn .btn-purple } | Game completed, all Roots burned |
