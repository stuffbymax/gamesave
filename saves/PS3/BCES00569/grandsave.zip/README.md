---
layout: default
title: "Gran Turismo 5"
parent: PS3 Saves
permalink: PS3/BCES00569/
---
# Gran Turismo 5

## PS3 Saves - BCES00569

| Icon | Filename | Description |
|------|----------|-------------|
| ![Gran Turismo 5](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Game completed 100% & 1144 cars in the garage |
| ![Gran Turismo 5](ICON0.PNG) | [00000007.zip](00000007.zip){: .btn .btn-purple } | 900 cars, 20,000,000 credits, Trophy All challenge |
| ![Gran Turismo 5](ICON0.PNG) | [00190914.zip](00190914.zip){: .btn .btn-purple } | Play time: 43 day(s) Current Credits: Cr.15,608,178 B spec almost complete A spec just a few races lots of cars and money |
