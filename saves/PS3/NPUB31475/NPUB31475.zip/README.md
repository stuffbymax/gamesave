---
layout: default
title: "AKIBA'S TRIP UNDEAD & UNDRESSED"
parent: PS3 Saves
permalink: PS3/NPUB31475/
---
# AKIBA'S TRIP UNDEAD & UNDRESSED

## PS3 Saves - NPUB31475

| Icon | Filename | Description |
|------|----------|-------------|
| ![AKIBA'S TRIP UNDEAD & UNDRESSED](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, all secondary missions completed |
| ![AKIBA'S TRIP UNDEAD & UNDRESSED](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | system data |
