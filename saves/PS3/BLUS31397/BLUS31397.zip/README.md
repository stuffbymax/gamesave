---
layout: default
title: "Tales of Xillia 2"
parent: PS3 Saves
permalink: PS3/BLUS31397/
---
# Tales of Xillia 2

## PS3 Saves - BLUS31397

| Icon | Filename | Description |
|------|----------|-------------|
| ![Tales of Xillia 2](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | new game plus unlocked, characters all maxed out |
