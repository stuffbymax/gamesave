---
layout: default
title: "Resident Evil Revelations"
parent: PS3 Saves
permalink: PS3/BLES01773/
---
# Resident Evil Revelations

## PS3 Saves - BLES01773

| Icon | Filename | Description |
|------|----------|-------------|
| ![Resident Evil Revelations](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, unlocked rocket launcher |
| ![Resident Evil Revelations](ICON0.PNG) | [00184041.zip](00184041.zip){: .btn .btn-purple } | Guns ammo health max |
