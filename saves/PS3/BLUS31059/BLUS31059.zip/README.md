---
layout: default
title: "Middle-Earth™: Shadow of Mordor™"
parent: PS3 Saves
permalink: PS3/BLUS31059/
---
# Middle-Earth™: Shadow of Mordor™

## PS3 Saves - BLUS31059

| Icon | Filename | Description |
|------|----------|-------------|
| ![Middle-Earth™: Shadow of Mordor™](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | starter save with max upgrade points and max attributes |
