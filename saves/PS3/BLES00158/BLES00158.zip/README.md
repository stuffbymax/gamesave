---
layout: default
title: "Assassin's Creed"
parent: PS3 Saves
permalink: PS3/BLES00158/
---
# Assassin's Creed

## PS3 Saves - BLES00158

| Icon | Filename | Description |
|------|----------|-------------|
| ![Assassin's Creed](ICON0.PNG) | [00017366.zip](00017366.zip){: .btn .btn-purple } | all memory blocks completed saved after credits no penalty when replaying all assassin flags collected. |
| ![Assassin's Creed](ICON0.PNG) | [00018361.zip](00018361.zip){: .btn .btn-purple } | 100% complete - All Flags, templars, memories collected, saved after credits. |
