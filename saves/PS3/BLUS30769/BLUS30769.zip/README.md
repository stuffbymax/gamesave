---
layout: default
title: "BLEACH: Soul Resurreccion"
parent: PS3 Saves
permalink: PS3/BLUS30769/
---
# BLEACH: Soul Resurreccion

## PS3 Saves - BLUS30769

| Icon | Filename | Description |
|------|----------|-------------|
| ![BLEACH: Soul Resurreccion](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, all characters fully upgraded |
| ![BLEACH: Soul Resurreccion](ICON0.PNG) | [00090235.zip](00090235.zip){: .btn .btn-purple } | All characters max level - All story chapters, missions, and difficulties unlocked |
