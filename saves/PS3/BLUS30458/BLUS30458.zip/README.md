---
layout: default
title: "Battlefield: Bad Company 2"
parent: PS3 Saves
permalink: PS3/BLUS30458/
---
# Battlefield: Bad Company 2

## PS3 Saves - BLUS30458

| Icon | Filename | Description |
|------|----------|-------------|
| ![Battlefield: Bad Company 2](ICON0.PNG) | [00001421.zip](00001421.zip){: .btn .btn-purple } | Completed game on Easy with all weapons and M-Coms found |
