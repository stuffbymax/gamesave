---
layout: default
title: "Nier"
parent: PS3 Saves
permalink: PS3/BLUS30481/
---
# Nier

## PS3 Saves - BLUS30481

| Icon | Filename | Description |
|------|----------|-------------|
| ![Nier](ICON0.PNG) | [00093350.zip](00093350.zip){: .btn .btn-purple } | THIS SAVE MIGHT REQUIRE ALL DLC - Max level - Best Words found - All 30 weapons found (32 with DLC) - But only the 3 best weapons are fully upgraded - Endings A & B obtained |
| ![Nier](ICON0.PNG) | [00230457.zip](00230457.zip){: .btn .btn-purple } | New Game+ (May Require DLC). Ending A & B done. |
