---
layout: default
title: "Aliens - Colonial Marines"
parent: PS3 Saves
permalink: PS3/BLES01455/
---
# Aliens - Colonial Marines

## PS3 Saves - BLES01455

| Icon | Filename | Description |
|------|----------|-------------|
| ![Aliens - Colonial Marines](ICON0.PNG) | [00230136.zip](00230136.zip){: .btn .btn-purple } | On first mission, soldier difficulty, Xeno and Marine upgrades 99, Xeno an Marine XP at 60. |
