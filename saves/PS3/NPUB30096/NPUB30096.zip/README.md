---
layout: default
title: "Hard Corps: Uprising"
parent: PS3 Saves
permalink: PS3/NPUB30096/
---
# Hard Corps: Uprising

## PS3 Saves - NPUB30096

| Icon | Filename | Description |
|------|----------|-------------|
| ![Hard Corps: Uprising](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Max CP + Rising Mode Completed Save |
| ![Hard Corps: Uprising](ICON0.PNG) | [00022819.zip](00022819.zip){: .btn .btn-purple } | 100% Unlocked May require DLC |
