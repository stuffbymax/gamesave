---
layout: default
title: "Dengeki Bunko Fighting Climax Ignition"
parent: PS3 Saves
permalink: PS3/NPJB00785/
---
# Dengeki Bunko Fighting Climax Ignition

## PS3 Saves - NPJB00785

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dengeki Bunko Fighting Climax Ignition](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | All Icons/Plates/Titles/Colors/Autographs/Characters purchased, Ignite Boost maxed out for all Playable/Support characters. (1.04) |
