---
layout: default
title: "Silent Hill 2/3 HD"
parent: PS3 Saves
permalink: PS3/BLUS30810/
---
# Silent Hill 2/3 HD

## PS3 Saves - BLUS30810

| Icon | Filename | Description |
|------|----------|-------------|
| ![Silent Hill 2/3 HD](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Silent Hill 3 HD, 100% completed (profile savedata) |
| ![Silent Hill 2/3 HD](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | Silent Hill 3 HD, 100% completed save |
| ![Silent Hill 2/3 HD](ICON0.PNG) | [00000003.zip](00000003.zip){: .btn .btn-purple } | Silent Hill 2 HD, 100% completed |
