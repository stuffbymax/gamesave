---
layout: default
title: "Dante's Inferno"
parent: PS3 Saves
permalink: PS3/BLUS30405/
---
# Dante's Inferno

## PS3 Saves - BLUS30405

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dante's Inferno](ICON0.PNG) | [00020301.zip](00020301.zip){: .btn .btn-purple } | New Game+ All Unholy and Holy - 100% Max All 3 Beatrice Stones Found. All Relics Unlocked and Upgraded [Except for 1 - eye of alighiero] You will need Dark Forest DLC For this save to work. |
