---
layout: default
title: "Deadpool"
parent: PS3 Saves
permalink: PS3/BLUS31146/
---
# Deadpool

## PS3 Saves - BLUS31146

| Icon | Filename | Description |
|------|----------|-------------|
| ![Deadpool](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, all upgrades unlocked |
