---
layout: default
title: "Tears to Tiara II: Heir of the Overload"
parent: PS3 Saves
permalink: PS3/BLUS31476/
---
# Tears to Tiara II: Heir of the Overload

## PS3 Saves - BLUS31476

| Icon | Filename | Description |
|------|----------|-------------|
| ![Tears to Tiara II: Heir of the Overload](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Max Level & Stats + Max Money Save |
