---
layout: default
title: "Far Cry 3"
parent: PS3 Saves
permalink: PS3/NPEB01096/
---
# Far Cry 3

## PS3 Saves - NPEB01096

| Icon | Filename | Description |
|------|----------|-------------|
| ![Far Cry 3](ICON0.PNG) | [00105403.zip](00105403.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Max XP - Max Skill Points - Max Money. |
