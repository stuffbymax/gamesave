---
layout: default
title: "Batman: Arkham Asylum"
parent: PS3 Saves
permalink: PS3/BLES00503/
---
# Batman: Arkham Asylum

## PS3 Saves - BLES00503

| Icon | Filename | Description |
|------|----------|-------------|
| ![Batman: Arkham Asylum](ICON0.PNG) | [00000910.zip](00000910.zip){: .btn .btn-purple } | Story mode finished on hard, Batman powers fully upgraded, all 240 riddles solved, Spirit of Arkham solved, all medals for stealth challenges obtained |
| ![Batman: Arkham Asylum](ICON0.PNG) | [00001062.zip](00001062.zip){: .btn .btn-purple } | Batman Arkham Asylum EU 100% Complete |
