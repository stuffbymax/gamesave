---
layout: default
title: "Aliens vs Predator"
parent: PS3 Saves
permalink: PS3/BLES00585/
---
# Aliens vs Predator

## PS3 Saves - BLES00585

| Icon | Filename | Description |
|------|----------|-------------|
| ![Aliens vs Predator](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed |
| ![Aliens vs Predator](ICON0.PNG) | [00170124.zip](00170124.zip){: .btn .btn-purple } | platinum save |
