---
layout: default
title: "Dead Island"
parent: PS3 Saves
permalink: PS3/BLUS30790/
---
# Dead Island

## PS3 Saves - BLUS30790

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dead Island](ICON0.PNG) | [00231852.zip](00231852.zip){: .btn .btn-purple } | Logan Level 60 Chapter 1. |
| ![Dead Island](ICON0.PNG) | [00232157.zip](00232157.zip){: .btn .btn-purple } | Purna Level 60 Chapter 1. |
