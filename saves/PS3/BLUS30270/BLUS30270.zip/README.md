---
layout: default
title: "RESIDENT EVIL 5 (Ver.2)"
parent: PS3 Saves
permalink: PS3/BLUS30270/
---
# RESIDENT EVIL 5 (Ver.2)

## PS3 Saves - BLUS30270

| Icon | Filename | Description |
|------|----------|-------------|
| ![RESIDENT EVIL 5 (Ver.2)](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | gold edition 100% completed, unlocked all weapons |
| ![RESIDENT EVIL 5 (Ver.2)](ICON0.PNG) | [00225352.zip](00225352.zip){: .btn .btn-purple } | Version 2.0. Max Money & Max Points. Everything Unocked. |
