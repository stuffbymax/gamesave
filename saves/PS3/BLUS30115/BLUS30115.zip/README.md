---
layout: default
title: "Condemned 2: Bloodshot"
parent: PS3 Saves
permalink: PS3/BLUS30115/
---
# Condemned 2: Bloodshot

## PS3 Saves - BLUS30115

| Icon | Filename | Description |
|------|----------|-------------|
| ![Condemned 2: Bloodshot](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Everything unlocked, gold, FPS mode. |
