---
layout: default
title: "Sacred Citadel"
parent: PS3 Saves
permalink: PS3/NPEB01212/
---
# Sacred Citadel

## PS3 Saves - NPEB01212

| Icon | Filename | Description |
|------|----------|-------------|
| ![Sacred Citadel](ICON0.PNG) | [00075751.zip](00075751.zip){: .btn .btn-purple } | Max Level. |
