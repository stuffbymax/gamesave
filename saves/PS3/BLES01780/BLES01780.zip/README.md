---
layout: default
title: "Tomb Raider"
parent: PS3 Saves
permalink: PS3/BLES01780/
---
# Tomb Raider

## PS3 Saves - BLES01780

| Icon | Filename | Description |
|------|----------|-------------|
| ![Tomb Raider](ICON0.PNG) | [00140927.zip](00140927.zip){: .btn .btn-purple } | Virgin Save [0%] - Cheats added: After obtaining an arrow [Arrow 40] - After point acquisition [Salvage 9999] - [Skill Point(s) 9999] - [HundGun 100] - [SubMachineGun 150] - [ShotGun 30] - [Grenade Launcher 7] |
