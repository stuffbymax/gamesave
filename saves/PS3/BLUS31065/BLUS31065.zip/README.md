---
layout: default
title: "The Walking Dead - Survival Instinct"
parent: PS3 Saves
permalink: PS3/BLUS31065/
---
# The Walking Dead - Survival Instinct

## PS3 Saves - BLUS31065

| Icon | Filename | Description |
|------|----------|-------------|
| ![The Walking Dead - Survival Instinct](ICON0.PNG) | [00225222.zip](00225222.zip){: .btn .btn-purple } | Max items in slots 1 to 10, health moifier 9999999, saved at police station about 30 mins into the game. |
