---
layout: default
title: "OKAMI HD"
parent: PS3 Saves
permalink: PS3/NPUB30720/
---
# OKAMI HD

## PS3 Saves - NPUB30720

| Icon | Filename | Description |
|------|----------|-------------|
| ![OKAMI HD](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, infinite health and ink unlocked |
