---
layout: default
title: "ONE PIECE: PIRATE WARRIORS"
parent: PS3 Saves
permalink: PS3/BLES01672/
---
# ONE PIECE: PIRATE WARRIORS

## PS3 Saves - BLES01672

| Icon | Filename | Description |
|------|----------|-------------|
| ![ONE PIECE: PIRATE WARRIORS](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | everything unlocked 100% completed, all upgrades maxed out |
