---
layout: default
title: "METAL GEAR SOLID PEACE WALKER HD EDITION"
parent: PS3 Saves
permalink: PS3/NPUB30611/
---
# METAL GEAR SOLID PEACE WALKER HD EDITION

## PS3 Saves - NPUB30611

| Icon | Filename | Description |
|------|----------|-------------|
| ![METAL GEAR SOLID PEACE WALKER HD EDITION](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed (ported from psp to ps3 savedata) |
| ![METAL GEAR SOLID PEACE WALKER HD EDITION](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | system data |
| ![METAL GEAR SOLID PEACE WALKER HD EDITION](ICON0.PNG) | [00044839.zip](00044839.zip){: .btn .btn-purple } | Cleared all MAIN OPS and EXTRA OPS missions and Acquired stealth camouflage. |
