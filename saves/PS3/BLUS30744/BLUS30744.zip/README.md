---
layout: default
title: "LEGO Pirates of the Caribbean: The Video Game"
parent: PS3 Saves
permalink: PS3/BLUS30744/
---
# LEGO Pirates of the Caribbean: The Video Game

## PS3 Saves - BLUS30744

| Icon | Filename | Description |
|------|----------|-------------|
| ![LEGO Pirates of the Caribbean: The Video Game](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% Complete / 23 billion studs |
