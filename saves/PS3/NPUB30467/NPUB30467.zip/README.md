---
layout: default
title: "Resident Evil Code: Veronica X HD"
parent: PS3 Saves
permalink: PS3/NPUB30467/
---
# Resident Evil Code: Veronica X HD

## PS3 Saves - NPUB30467

| Icon | Filename | Description |
|------|----------|-------------|
| ![Resident Evil Code: Veronica X HD](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Story Completed + Infinite Rocket Launcher + Linear Launcher |
