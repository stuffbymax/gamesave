---
layout: default
title: "Zone of the Enders HD Collection"
parent: PS3 Saves
permalink: PS3/BLUS30937/
---
# Zone of the Enders HD Collection

## PS3 Saves - BLUS30937

| Icon | Filename | Description |
|------|----------|-------------|
| ![Zone of the Enders HD Collection](ICON0.PNG) | [00063558.zip](00063558.zip){: .btn .btn-purple } | Zone of the Enders - Save 1 Allows you to obtain - Damage Control and Good Samaritan. Save 3 Allows you to obtain - Valedictorian. Save 4 Allows you to Obtain - Gun Runner |
| ![Zone of the Enders HD Collection](ICON0.PNG) | [00063743.zip](00063743.zip){: .btn .btn-purple } | Zone of the Enders: The 2nd Runner - Campaign Mode completed. (Normal Difficulty). All Orbital Frames Unlocked For VS Mode. All Jehuty Orbital Frames Unlocked for Campaign Mode. |
