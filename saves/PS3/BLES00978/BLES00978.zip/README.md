---
layout: default
title: "Dragon Ball: Raging Blast 2"
parent: PS3 Saves
permalink: PS3/BLES00978/
---
# Dragon Ball: Raging Blast 2

## PS3 Saves - BLES00978

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dragon Ball: Raging Blast 2](ICON0.PNG) | [10000000.zip](10000000.zip){: .btn .btn-purple } | 100% Complete All Unlocked |
| ![Dragon Ball: Raging Blast 2](ICON0.PNG) | [12345678.zip](12345678.zip){: .btn .btn-purple } | Galaxy mode 100%, all 620 medals, items and pictures 100% |
