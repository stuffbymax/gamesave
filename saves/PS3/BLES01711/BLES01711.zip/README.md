---
layout: default
title: "X-COM - Enemy Unknown"
parent: PS3 Saves
permalink: PS3/BLES01711/
---
# X-COM - Enemy Unknown

## PS3 Saves - BLES01711

| Icon | Filename | Description |
|------|----------|-------------|
| ![X-COM - Enemy Unknown](ICON0.PNG) | [00123442.zip](00123442.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Max Health - Max Cash - Max Defense. |
| ![X-COM - Enemy Unknown](ICON0.PNG) | [00080026.zip](00080026.zip){: .btn .btn-purple } | Max Health Max Offence MaxDefence Max Cash Max Armor Impossible Iron Man |
