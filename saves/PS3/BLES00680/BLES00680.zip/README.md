---
layout: default
title: "Red Dead Redemption"
parent: PS3 Saves
permalink: PS3/BLES00680/
---
# Red Dead Redemption

## PS3 Saves - BLES00680

| Icon | Filename | Description |
|------|----------|-------------|
| ![Red Dead Redemption](ICON0.PNG) | [00115708.zip](00115708.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Online Multiplayer - Level 50 5th Prestige - All Golden Guns. |
