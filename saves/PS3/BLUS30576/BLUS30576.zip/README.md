---
layout: default
title: "BlazBlue: Continuum Shift"
parent: PS3 Saves
permalink: PS3/BLUS30576/
---
# BlazBlue: Continuum Shift

## PS3 Saves - BLUS30576

| Icon | Filename | Description |
|------|----------|-------------|
| ![BlazBlue: Continuum Shift](ICON0.PNG) | [00001259.zip](00001259.zip){: .btn .btn-purple } | Story complete and Mu-12 unlocked. |
| ![BlazBlue: Continuum Shift](ICON0.PNG) | [00030576.zip](00030576.zip){: .btn .btn-purple } | If you have a partner to boost,1 hour for all online trophies. |
