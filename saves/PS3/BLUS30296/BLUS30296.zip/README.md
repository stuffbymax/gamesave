---
layout: default
title: "Singularity"
parent: PS3 Saves
permalink: PS3/BLUS30296/
---
# Singularity

## PS3 Saves - BLUS30296

| Icon | Filename | Description |
|------|----------|-------------|
| ![Singularity](ICON0.PNG) | [00121200.zip](00121200.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: E99 Tech - Max Health Packs - Max Ammo AR9 - Max Ammo Volk S4 - Max Ammo Centurion. |
