---
layout: default
title: "Castlevania Lords of Shadow™"
parent: PS3 Saves
permalink: PS3/BLUS30339/
---
# Castlevania Lords of Shadow™

## PS3 Saves - BLUS30339

| Icon | Filename | Description |
|------|----------|-------------|
| ![Castlevania Lords of Shadow™](ICON0.PNG) | [00001198.zip](00001198.zip){: .btn .btn-purple } | Everything Unlocked, 110% all missions |
| ![Castlevania Lords of Shadow™](ICON0.PNG) | [00001199.zip](00001199.zip){: .btn .btn-purple } | Knight Mode Run without any upgrades, sort of a fresh game in paladin mode |
| ![Castlevania Lords of Shadow™](ICON0.PNG) | [00233936.zip](00233936.zip){: .btn .btn-purple } | Max Experience Game Finished Activate Cheats (May Require DLC) |
