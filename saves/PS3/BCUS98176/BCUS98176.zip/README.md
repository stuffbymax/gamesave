---
layout: default
title: "Resistance 3"
parent: PS3 Saves
permalink: PS3/BCUS98176/
---
# Resistance 3

## PS3 Saves - BCUS98176

| Icon | Filename | Description |
|------|----------|-------------|
| ![Resistance 3](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | All Extra & Cheats Unlocked + Trophy Popper Save |
