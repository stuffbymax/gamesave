---
layout: default
title: "FINAL FANTASY X & X-2 HD Remaster"
parent: PS3 Saves
permalink: PS3/BLUS31211/
---
# FINAL FANTASY X & X-2 HD Remaster

## PS3 Saves - BLUS31211

| Icon | Filename | Description |
|------|----------|-------------|
| ![FINAL FANTASY X & X-2 HD Remaster](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Starter save for FF X-2. Max Gil, All Items x99, All Level 99, Max HP & MP |
