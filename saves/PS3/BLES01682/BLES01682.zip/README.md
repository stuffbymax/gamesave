---
layout: default
title: "Way Of The Samurai 4"
parent: PS3 Saves
permalink: PS3/BLES01682/
---
# Way Of The Samurai 4

## PS3 Saves - BLES01682

| Icon | Filename | Description |
|------|----------|-------------|
| ![Way Of The Samurai 4](ICON0.PNG) | [00123202.zip](00123202.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Max Life - Max Vitality - Max Funds - Max Samurai Points - Max Soul Moves. |
