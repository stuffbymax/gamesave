---
layout: default
title: "Duke Nukem 3D Megaton Edition"
parent: PS3 Saves
permalink: PS3/NPUB31378/
---
# Duke Nukem 3D Megaton Edition

## PS3 Saves - NPUB31378

| Icon | Filename | Description |
|------|----------|-------------|
| ![Duke Nukem 3D Megaton Edition](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Game completed, All episodes completed |
