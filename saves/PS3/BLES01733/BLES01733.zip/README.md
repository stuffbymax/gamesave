---
layout: default
title: "Dead Space™ 3"
parent: PS3 Saves
permalink: PS3/BLES01733/
---
# Dead Space™ 3

## PS3 Saves - BLES01733

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dead Space™ 3](ICON0.PNG) | [00113200.zip](00113200.zip){: .btn .btn-purple } | Each save has completed all chapters and modded resources, just beat final boss for trophy. |
| ![Dead Space™ 3](ICON0.PNG) | [00234317.zip](00234317.zip){: .btn .btn-purple } | Pure survival, max health, 100 inventory slots, max items, DEVIL HORNS UNLOCKED, max air, stasis and kenesis |
