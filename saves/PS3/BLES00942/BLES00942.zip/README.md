---
layout: default
title: "Max Payne 3"
parent: PS3 Saves
permalink: PS3/BLES00942/
---
# Max Payne 3

## PS3 Saves - BLES00942

| Icon | Filename | Description |
|------|----------|-------------|
| ![Max Payne 3](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | A few things unlocked, save is right before Hard Mode ending, some weapons have been collected, some MP progression inside the save as well |
| ![Max Payne 3](ICON0.PNG) | [00014356.zip](00014356.zip){: .btn .btn-purple } | All Chapter Unlock |
