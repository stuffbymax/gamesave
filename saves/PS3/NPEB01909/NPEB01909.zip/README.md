---
layout: default
title: "Valiant Hearts: The Great War"
parent: PS3 Saves
permalink: PS3/NPEB01909/
---
# Valiant Hearts: The Great War

## PS3 Saves - NPEB01909

| Icon | Filename | Description |
|------|----------|-------------|
| ![Valiant Hearts: The Great War](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | 100% completed, platinum save. |
