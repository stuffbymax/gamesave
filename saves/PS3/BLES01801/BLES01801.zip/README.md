---
layout: default
title: "Fist of the North Star: Ken's Rage 2"
parent: PS3 Saves
permalink: PS3/BLES01801/
---
# Fist of the North Star: Ken's Rage 2

## PS3 Saves - BLES01801

| Icon | Filename | Description |
|------|----------|-------------|
| ![Fist of the North Star: Ken's Rage 2](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Trophy unlock #1. Play the "Legend" mode by selecting chapters to unlock the related trophies. |
| ![Fist of the North Star: Ken's Rage 2](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | Trophy unlock #2. Go to "Dream" mode and select Toki, go to "Scrolls," remove any one of them and reequip it to unlock the "Ultimate Nexus Master" trophy. |
