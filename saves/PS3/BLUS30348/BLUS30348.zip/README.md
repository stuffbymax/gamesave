---
layout: default
title: "Cross Edge"
parent: PS3 Saves
permalink: PS3/BLUS30348/
---
# Cross Edge

## PS3 Saves - BLUS30348

| Icon | Filename | Description |
|------|----------|-------------|
| ![Cross Edge](ICON0.PNG) | [00074938.zip](00074938.zip){: .btn .btn-purple } | Platinum Save - Everything is done, all weapons, armors, accessories, items, skills and active skills in inventory, along with all books, tomes, etc. |
