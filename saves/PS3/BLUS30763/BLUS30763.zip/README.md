---
layout: default
title: "Dead Rising 2 - Off The Record"
parent: PS3 Saves
permalink: PS3/BLUS30763/
---
# Dead Rising 2 - Off The Record

## PS3 Saves - BLUS30763

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dead Rising 2 - Off The Record](ICON0.PNG) | [00100306.zip](00100306.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Level 50 Character - Infinite Health - Running Speed 3x - Maxed Skills - 1,004,814,319 PP - 1,920,029,800 Money - 9,999,999 Zombies Killed - Infinite ammo - Unbreakable weapons |
