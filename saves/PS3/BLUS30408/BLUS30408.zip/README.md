---
layout: default
title: "Army of Two: The 40th Day"
parent: PS3 Saves
permalink: PS3/BLUS30408/
---
# Army of Two: The 40th Day

## PS3 Saves - BLUS30408

| Icon | Filename | Description |
|------|----------|-------------|
| ![Army of Two: The 40th Day](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Game is 100% Completed |
