---
layout: default
title: "Altered Beast"
parent: PS3 Saves
permalink: PS3/NPUB30459/
---
# Altered Beast

## PS3 Saves - NPUB30459

| Icon | Filename | Description |
|------|----------|-------------|
| ![Altered Beast](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Game completed, Quick Save after defeating last boss |
