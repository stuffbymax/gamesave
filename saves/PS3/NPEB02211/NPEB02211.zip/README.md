---
layout: default
title: "ONE PIECE: PIRATE WARRIORS 3"
parent: PS3 Saves
permalink: PS3/NPEB02211/
---
# ONE PIECE: PIRATE WARRIORS 3

## PS3 Saves - NPEB02211

| Icon | Filename | Description |
|------|----------|-------------|
| ![ONE PIECE: PIRATE WARRIORS 3](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, unlocked all characters |
