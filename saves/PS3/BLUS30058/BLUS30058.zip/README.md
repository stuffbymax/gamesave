---
layout: default
title: "Dynasty Warriors: Gundam"
parent: PS3 Saves
permalink: PS3/BLUS30058/
---
# Dynasty Warriors: Gundam

## PS3 Saves - BLUS30058

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dynasty Warriors: Gundam](ICON0.PNG) | [00017585.zip](00017585.zip){: .btn .btn-purple } | All Pilot's Stories Completed & All Mobile Suits Unlocked |
| ![Dynasty Warriors: Gundam](ICON0.PNG) | [00015705.zip](00015705.zip){: .btn .btn-purple } | All Mobile Suits Unlocked and All Pilots Level 30 except Puru Two and Emma |
