---
layout: default
title: "LEGO Star Wars: The Force Awakens"
parent: PS3 Saves
permalink: PS3/BLES02213/
---
# LEGO Star Wars: The Force Awakens

## PS3 Saves - BLES02213

| Icon | Filename | Description |
|------|----------|-------------|
| ![LEGO Star Wars: The Force Awakens](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Story 100% Complete, DLCs untouched |
