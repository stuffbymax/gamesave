---
layout: default
title: "BlazBlue: Calamity Trigger"
parent: PS3 Saves
permalink: PS3/BLUS30392/
---
# BlazBlue: Calamity Trigger

## PS3 Saves - BLUS30392

| Icon | Filename | Description |
|------|----------|-------------|
| ![BlazBlue: Calamity Trigger](ICON0.PNG) | [00023581.zip](00023581.zip){: .btn .btn-purple } | Empty profile account. Story mode and arcade completed with all characters ending. |
