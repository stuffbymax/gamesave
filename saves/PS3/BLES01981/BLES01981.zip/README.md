---
layout: default
title: "SNIPER ELITE III"
parent: PS3 Saves
permalink: PS3/BLES01981/
---
# SNIPER ELITE III

## PS3 Saves - BLES01981

| Icon | Filename | Description |
|------|----------|-------------|
| ![SNIPER ELITE III](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | max level, all weapons unlocked, all missions available |
| ![SNIPER ELITE III](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | profle savedata |
