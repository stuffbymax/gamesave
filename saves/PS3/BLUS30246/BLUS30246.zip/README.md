---
layout: default
title: "Mortal Kombat vs DC Universe"
parent: PS3 Saves
permalink: PS3/BLUS30246/
---
# Mortal Kombat vs DC Universe

## PS3 Saves - BLUS30246

| Icon | Filename | Description |
|------|----------|-------------|
| ![Mortal Kombat vs DC Universe](ICON0.PNG) | [00033138.zip](00033138.zip){: .btn .btn-purple } | Unlock All Characters Unlock Ending |
