---
layout: default
title: "Killzone 2"
parent: PS3 Saves
permalink: PS3/BCES00081/
---
# Killzone 2

## PS3 Saves - BCES00081

| Icon | Filename | Description |
|------|----------|-------------|
| ![Killzone 2](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | game completed save |
| ![Killzone 2](ICON0.PNG) | [00172700.zip](00172700.zip){: .btn .btn-purple } | platinum save |
