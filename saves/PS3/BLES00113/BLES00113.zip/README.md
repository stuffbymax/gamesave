---
layout: default
title: "Bladestorm: The Hundred Years' War"
parent: PS3 Saves
permalink: PS3/BLES00113/
---
# Bladestorm: The Hundred Years' War

## PS3 Saves - BLES00113

| Icon | Filename | Description |
|------|----------|-------------|
| ![Bladestorm: The Hundred Years' War](ICON0.PNG) | [00000322.zip](00000322.zip){: .btn .btn-purple } | 100% Game Clear |
| ![Bladestorm: The Hundred Years' War](ICON0.PNG) | [00000459.zip](00000459.zip){: .btn .btn-purple } | Main story complete, still lots to unlock! |
