---
layout: default
title: "Hell Yeah! Wrath Of The Dead Rabbit"
parent: PS3 Saves
permalink: PS3/NPUB30750/
---
# Hell Yeah! Wrath Of The Dead Rabbit

## PS3 Saves - NPUB30750

| Icon | Filename | Description |
|------|----------|-------------|
| ![Hell Yeah! Wrath Of The Dead Rabbit](ICON0.PNG) | [00102837.zip](00102837.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheat added: Max money[99999]. |
