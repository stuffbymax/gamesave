---
layout: default
title: "Record Of Agarest War 2"
parent: PS3 Saves
permalink: PS3/BLUS30881/
---
# Record Of Agarest War 2

## PS3 Saves - BLUS30881

| Icon | Filename | Description |
|------|----------|-------------|
| ![Record Of Agarest War 2](ICON0.PNG) | [00115507.zip](00115507.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: 999999999 G/PP/TP - 99 Plat Soul Coin - 65535 HP - 999 AP. |
