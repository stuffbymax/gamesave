---
layout: default
title: "Dead Rising 2"
parent: PS3 Saves
permalink: PS3/BLUS30439/
---
# Dead Rising 2

## PS3 Saves - BLUS30439

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dead Rising 2](ICON0.PNG) | [00001263.zip](00001263.zip){: .btn .btn-purple } | Lvl 50 At first mission before giving Katey Zombrex |
