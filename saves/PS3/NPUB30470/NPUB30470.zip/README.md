---
layout: default
title: "Battle Los Angeles"
parent: PS3 Saves
permalink: PS3/NPUB30470/
---
# Battle Los Angeles

## PS3 Saves - NPUB30470

| Icon | Filename | Description |
|------|----------|-------------|
| ![Battle Los Angeles](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Game Completed on all 3 difficulties, Gallery Unlocked |
