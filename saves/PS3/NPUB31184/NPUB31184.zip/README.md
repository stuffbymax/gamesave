---
layout: default
title: "Ninja Gaiden 3 - Razors Edge"
parent: PS3 Saves
permalink: PS3/NPUB31184/
---
# Ninja Gaiden 3 - Razors Edge

## PS3 Saves - NPUB31184

| Icon | Filename | Description |
|------|----------|-------------|
| ![Ninja Gaiden 3 - Razors Edge](ICON0.PNG) | [00114519.zip](00114519.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Max Health - Max Mana - Ryu Karma 999,999,999 - Ayane Karma 999,999,999. |
| ![Ninja Gaiden 3 - Razors Edge](ICON0.PNG) | [00235310.zip](00235310.zip){: .btn .btn-purple } | All characters/costumes/weapons unlocked & skills learned - All Chapter Challenge stages unlocked - All Lifebar upgrades found |
