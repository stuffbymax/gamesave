---
layout: default
title: "METAL GEAR SOLID 4 GUNS OF THE PATRIOTS"
parent: PS3 Saves
permalink: PS3/BLUS30109/
---
# METAL GEAR SOLID 4 GUNS OF THE PATRIOTS

## PS3 Saves - BLUS30109

| Icon | Filename | Description |
|------|----------|-------------|
| ![METAL GEAR SOLID 4 GUNS OF THE PATRIOTS](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, all weapons upgraded |
| ![METAL GEAR SOLID 4 GUNS OF THE PATRIOTS](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | profile savedata |
| ![METAL GEAR SOLID 4 GUNS OF THE PATRIOTS](ICON0.PNG) | [00030026.zip](00030026.zip){: .btn .btn-purple } | Max DP Max Rations Infinite Ammo Max Items Unlock The Boss Extreme Difficulty |
