---
layout: default
title: "The Elder Scrolls V: Skyrim"
parent: PS3 Saves
permalink: PS3/BLES01329/
---
# The Elder Scrolls V: Skyrim

## PS3 Saves - BLES01329

| Icon | Filename | Description |
|------|----------|-------------|
| ![The Elder Scrolls V: Skyrim](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Main Story Quests Completed (100%) |
| ![The Elder Scrolls V: Skyrim](ICON0.PNG) | [00062953.zip](00062953.zip){: .btn .btn-purple } | Platinum Save |
| ![The Elder Scrolls V: Skyrim](ICON0.PNG) | [00173615.zip](00173615.zip){: .btn .btn-purple } | starter female , no skill, no perk , no shout, lvl 1 , item + max pv, mana,gold |
| ![The Elder Scrolls V: Skyrim](ICON0.PNG) | [00173656.zip](00173656.zip){: .btn .btn-purple } | starter male , no skill, no perk , no shout, lvl 1 , item + max pv, mana,gold |
