---
layout: default
title: "Trine 2"
parent: PS3 Saves
permalink: PS3/NPEB00668/
---
# Trine 2

## PS3 Saves - NPEB00668

| Icon | Filename | Description |
|------|----------|-------------|
| ![Trine 2](ICON0.PNG) | [00062515.zip](00062515.zip){: .btn .btn-purple } | Platinum Save |
