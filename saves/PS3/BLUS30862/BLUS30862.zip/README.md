---
layout: default
title: "Aliens - Colonial Marines"
parent: PS3 Saves
permalink: PS3/BLUS30862/
---
# Aliens - Colonial Marines

## PS3 Saves - BLUS30862

| Icon | Filename | Description |
|------|----------|-------------|
| ![Aliens - Colonial Marines](ICON0.PNG) | [00195403.zip](00195403.zip){: .btn .btn-purple } | This save is at the start of the first mission on soldier difficulty, xeno and marine upgrades at 99, XP both at 60 |
