---
layout: default
title: "Dead Island - Riptide"
parent: PS3 Saves
permalink: PS3/BLES01739/
---
# Dead Island - Riptide

## PS3 Saves - BLES01739

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dead Island - Riptide](ICON0.PNG) | [00014934.zip](00014934.zip){: .btn .btn-purple } | All Characters Level 70 Dev M60 Max Cash Max Skills Chapter 1 John on Chapter 2 with some weapons. |
| ![Dead Island - Riptide](ICON0.PNG) | [00185333.zip](00185333.zip){: .btn .btn-purple } | Purna level 65, ferry station, lots of firearms with 9999999 ammo, all craft parts at 9999, lots of mele weapons all purple, blue, yellow an green, Kens box is also full with modded purple, blue, yellow an green mele weapons an firearms only |
