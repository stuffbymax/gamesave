---
layout: default
title: "BlazBlue: Calamity Trigger"
parent: PS3 Saves
permalink: PS3/BLES00820/
---
# BlazBlue: Calamity Trigger

## PS3 Saves - BLES00820

| Icon | Filename | Description |
|------|----------|-------------|
| ![BlazBlue: Calamity Trigger](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | platinum save |
| ![BlazBlue: Calamity Trigger](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | replay theater, view videos for trophy |
| ![BlazBlue: Calamity Trigger](ICON0.PNG) | [00050898.zip](00050898.zip){: .btn .btn-purple } | Game done 100% (system) |
| ![BlazBlue: Calamity Trigger](ICON0.PNG) | [00050899.zip](00050899.zip){: .btn .btn-purple } | Game done 100% (replay) |
