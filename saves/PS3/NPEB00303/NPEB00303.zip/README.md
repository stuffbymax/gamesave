---
layout: default
title: "Crazy Taxi"
parent: PS3 Saves
permalink: PS3/NPEB00303/
---
# Crazy Taxi

## PS3 Saves - NPEB00303

| Icon | Filename | Description |
|------|----------|-------------|
| ![Crazy Taxi](ICON0.PNG) | [00172351.zip](00172351.zip){: .btn .btn-purple } | platinum save |
