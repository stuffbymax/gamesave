---
layout: default
title: "inFamous"
parent: PS3 Saves
permalink: PS3/BCES00609/
---
# inFamous

## PS3 Saves - BCES00609

| Icon | Filename | Description |
|------|----------|-------------|
| ![inFamous](ICON0.PNG) | [00092418.zip](00092418.zip){: .btn .btn-purple } | 100% completed |
