---
layout: default
title: "Metal Gear Rising - Revengeance"
parent: PS3 Saves
permalink: PS3/BLUS31045/
---
# Metal Gear Rising - Revengeance

## PS3 Saves - BLUS31045

| Icon | Filename | Description |
|------|----------|-------------|
| ![Metal Gear Rising - Revengeance](ICON0.PNG) | [00190823.zip](00190823.zip){: .btn .btn-purple } | max hp all weapons unlocked and special weapons max items  |
