---
layout: default
title: "Hot Shots Golf - World Invitational"
parent: PS3 Saves
permalink: PS3/NPUA80864/
---
# Hot Shots Golf - World Invitational

## PS3 Saves - NPUA80864

| Icon | Filename | Description |
|------|----------|-------------|
| ![Hot Shots Golf - World Invitational](ICON0.PNG) | [00023203.zip](00023203.zip){: .btn .btn-purple } | Virgin Save[0%]: Max Current Points and Max Cumulative Points. |
