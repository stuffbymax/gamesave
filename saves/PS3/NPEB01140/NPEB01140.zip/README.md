---
layout: default
title: "Tekken Tag Tournament 2"
parent: PS3 Saves
permalink: PS3/NPEB01140/
---
# Tekken Tag Tournament 2

## PS3 Saves - NPEB01140

| Icon | Filename | Description |
|------|----------|-------------|
| ![Tekken Tag Tournament 2](ICON0.PNG) | [00124903.zip](00124903.zip){: .btn .btn-purple } | Platinum Save |
