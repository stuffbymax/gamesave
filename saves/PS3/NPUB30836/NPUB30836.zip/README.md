---
layout: default
title: "One Piece - Pirate Warriors"
parent: PS3 Saves
permalink: PS3/NPUB30836/
---
# One Piece - Pirate Warriors

## PS3 Saves - NPUB30836

| Icon | Filename | Description |
|------|----------|-------------|
| ![One Piece - Pirate Warriors](ICON0.PNG) | [00093644.zip](00093644.zip){: .btn .btn-purple } | All Characters unlocked & max level - All Main Log & Another Log chapters unlocked - All Coins 4-Starred & of varying effects and abilities - All relationships between Coins discovered - Only the best Skill Combinations discovered |
