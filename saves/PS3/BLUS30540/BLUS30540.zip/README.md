---
layout: default
title: "LEGO Star Wars III: The Clone Wars"
parent: PS3 Saves
permalink: PS3/BLUS30540/
---
# LEGO Star Wars III: The Clone Wars

## PS3 Saves - BLUS30540

| Icon | Filename | Description |
|------|----------|-------------|
| ![LEGO Star Wars III: The Clone Wars](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% complete, 679 billion studs |
