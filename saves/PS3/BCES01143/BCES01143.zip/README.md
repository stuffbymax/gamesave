---
layout: default
title: "inFamous 2"
parent: PS3 Saves
permalink: PS3/BCES01143/
---
# inFamous 2

## PS3 Saves - BCES01143

| Icon | Filename | Description |
|------|----------|-------------|
| ![inFamous 2](ICON0.PNG) | [00111620.zip](00111620.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheat added: Max XP. |
