---
layout: default
title: "Uncharted 3: Drake's Deception™"
parent: PS3 Saves
permalink: PS3/BCUS98233/
---
# Uncharted 3: Drake's Deception™

## PS3 Saves - BCUS98233

| Icon | Filename | Description |
|------|----------|-------------|
| ![Uncharted 3: Drake's Deception™](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | unlocked all treasures, all cheats available |
| ![Uncharted 3: Drake's Deception™](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | unlocked all treasures, all cheats available (profile savedata) |
| ![Uncharted 3: Drake's Deception™](ICON0.PNG) | [00122411.zip](00122411.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Crushing Difficulty Unlocked - All Chapters Unlocked - Max ammo - Max Grenades. |
