---
layout: default
title: "Need for Speed: Carbon"
parent: PS3 Saves
permalink: PS3/SLUS21493/
---
# Need for Speed: Carbon

## PS3 Saves - SLUS21493

| Icon | Filename | Description |
|------|----------|-------------|
| ![Need for Speed: Carbon](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | NFS Carbon Save with DLC unlocked. (10 extra cars from Collectors Edition) |
