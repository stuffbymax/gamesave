---
layout: default
title: "LIGHTNING RETURNS: FINAL FANTASY XIII"
parent: PS3 Saves
permalink: PS3/BLJM60558/
---
# LIGHTNING RETURNS: FINAL FANTASY XIII

## PS3 Saves - BLJM60558

| Icon | Filename | Description |
|------|----------|-------------|
| ![LIGHTNING RETURNS: FINAL FANTASY XIII](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, unlock all equipment, ligtning all max out stats |
| ![LIGHTNING RETURNS: FINAL FANTASY XIII](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | Starter save, 3rd round through the game. Weapons, shields, accessories, decorations. All 71 in-game costumes unlocked. |
