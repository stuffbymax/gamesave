---
layout: default
title: "Call Of Duty Black Ops"
parent: PS3 Saves
permalink: PS3/BLUS30591/
---
# Call Of Duty Black Ops

## PS3 Saves - BLUS30591

| Icon | Filename | Description |
|------|----------|-------------|
| ![Call Of Duty Black Ops](ICON0.PNG) | [00001261.zip](00001261.zip){: .btn .btn-purple } | All Missions COMPLETE on Veteran. 40/42 Intel |
| ![Call Of Duty Black Ops](ICON0.PNG) | [00001262.zip](00001262.zip){: .btn .btn-purple } | All Trophies from the main game and only 93% Online |
| ![Call Of Duty Black Ops](ICON0.PNG) | [00001231.zip](00001231.zip){: .btn .btn-purple } | single player finished |
