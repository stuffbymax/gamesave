---
layout: default
title: "Young Justice: Legacy"
parent: PS3 Saves
permalink: PS3/BLUS31170/
---
# Young Justice: Legacy

## PS3 Saves - BLUS31170

| Icon | Filename | Description |
|------|----------|-------------|
| ![Young Justice: Legacy](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed |
