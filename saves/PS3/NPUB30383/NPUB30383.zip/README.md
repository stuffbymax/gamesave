---
layout: default
title: "I Am Alive"
parent: PS3 Saves
permalink: PS3/NPUB30383/
---
# I Am Alive

## PS3 Saves - NPUB30383

| Icon | Filename | Description |
|------|----------|-------------|
| ![I Am Alive](ICON0.PNG) | [00232534.zip](00232534.zip){: .btn .btn-purple } | Start of game on hard mode with 9999 Retries, 9999 Ammo and 99 Items. |
