---
layout: default
title: "Shoot Many Robots"
parent: PS3 Saves
permalink: PS3/NPEB00767/
---
# Shoot Many Robots

## PS3 Saves - NPEB00767

| Icon | Filename | Description |
|------|----------|-------------|
| ![Shoot Many Robots](ICON0.PNG) | [00075534.zip](00075534.zip){: .btn .btn-purple } | Max cash and level 50 at the start of the game. |
