---
layout: default
title: "Splatterhouse"
parent: PS3 Saves
permalink: PS3/BLUS30335/
---
# Splatterhouse

## PS3 Saves - BLUS30335

| Icon | Filename | Description |
|------|----------|-------------|
| ![Splatterhouse](ICON0.PNG) | [00121608.zip](00121608.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: All Health Upgrades - Max Blood - Skill Menu Unlocked - Brutal Difficulty Unlocked - Classics Unlocked - Survival Mode Unlocked. |
| ![Splatterhouse](ICON0.PNG) | [00215830.zip](00215830.zip){: .btn .btn-purple } | Max blood an classics unlocked |
| ![Splatterhouse](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% Save File (No DLC Maps) |
