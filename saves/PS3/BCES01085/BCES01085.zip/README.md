---
layout: default
title: "White Knight Chronicles II"
parent: PS3 Saves
permalink: PS3/BCES01085/
---
# White Knight Chronicles II

## PS3 Saves - BCES01085

| Icon | Filename | Description |
|------|----------|-------------|
| ![White Knight Chronicles II](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | New Game - All/Max Items - Max Money |
| ![White Knight Chronicles II](ICON0.PNG) | [00173925.zip](00173925.zip){: .btn .btn-purple } | starter save lvl 80 ,rg 30(-1xp), max money,daliah,stats. |
