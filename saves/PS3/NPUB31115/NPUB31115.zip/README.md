---
layout: default
title: "Atelier Ayesha - The Alchemist Of Dusk"
parent: PS3 Saves
permalink: PS3/NPUB31115/
---
# Atelier Ayesha - The Alchemist Of Dusk

## PS3 Saves - NPUB31115

| Icon | Filename | Description |
|------|----------|-------------|
| ![Atelier Ayesha - The Alchemist Of Dusk](ICON0.PNG) | [00093041.zip](00093041.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Slot 1: Max Money and EXP for Cole and Meruru - Slot 2: Max Money, EXP and Status(including speed) - Slot 3: Max Money, EXP and Status(excluding speed) |
