---
layout: default
title: "Star Wars - The Force Unleashed"
parent: PS3 Saves
permalink: PS3/BLUS30445/
---
# Star Wars - The Force Unleashed

## PS3 Saves - BLUS30445

| Icon | Filename | Description |
|------|----------|-------------|
| ![Star Wars - The Force Unleashed](ICON0.PNG) | [00120520.zip](00120520.zip){: .btn .btn-purple } | Unlock All Cinematics Unlock All Art Unlock All Lightsabers Max Force Spheres Play As - Darth Vader Play As - Starkiller Play As - Training Gear |
| ![Star Wars - The Force Unleashed](ICON0.PNG) | [00122150.zip](00122150.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Sith Master Difficulty Unlocked - All Lightsabers Unlocked - Max Force Spheres: Force Combos - Force Powers - Force Talent. |
