---
layout: default
title: "Under Defeat HD"
parent: PS3 Saves
permalink: PS3/BLUS31077/
---
# Under Defeat HD

## PS3 Saves - BLUS31077

| Icon | Filename | Description |
|------|----------|-------------|
| ![Under Defeat HD](ICON0.PNG) | [00012758.zip](00012758.zip){: .btn .btn-purple } | Infinite Credits - Unlock Free Play |
