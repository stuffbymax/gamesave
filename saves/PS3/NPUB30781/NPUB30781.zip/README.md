---
layout: default
title: "Hitman: Blood Money"
parent: PS3 Saves
permalink: PS3/NPUB30781/
---
# Hitman: Blood Money

## PS3 Saves - NPUB30781

| Icon | Filename | Description |
|------|----------|-------------|
| ![Hitman: Blood Money](ICON0.PNG) | [00235035.zip](00235035.zip){: .btn .btn-purple } | Professional Difficulty completed. Max Money as well. All But One Attachment For Every Weapon. |
