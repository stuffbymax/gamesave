---
layout: default
title: "Dynasty Warriors 8: Xtreme Legends"
parent: PS3 Saves
permalink: PS3/NPUB31449/
---
# Dynasty Warriors 8: Xtreme Legends

## PS3 Saves - NPUB31449

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dynasty Warriors 8: Xtreme Legends](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | All Characters Level 50 + Attack & Defense Max Level Save |
