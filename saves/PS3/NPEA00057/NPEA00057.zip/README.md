---
layout: default
title: "WipEout® HD"
parent: PS3 Saves
permalink: PS3/NPEA00057/
---
# WipEout® HD

## PS3 Saves - NPEA00057

| Icon | Filename | Description |
|------|----------|-------------|
| ![WipEout® HD](ICON0.PNG) | [00000003.zip](00000003.zip){: .btn .btn-purple } | HD and Fury campaign 100% complete - All gold medals on at least skilled, All skins unlocked |
| ![WipEout® HD](ICON0.PNG) | [00230341.zip](00230341.zip){: .btn .btn-purple } | All Ships and Tracks Unlock. (May Require Fury DLC) |
| ![WipEout® HD](ICON0.PNG) | [00174008.zip](00174008.zip){: .btn .btn-purple } | platinum save |
