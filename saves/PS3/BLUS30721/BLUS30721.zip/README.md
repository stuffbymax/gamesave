---
layout: default
title: "ASURA'S WRATH"
parent: PS3 Saves
permalink: PS3/BLUS30721/
---
# ASURA'S WRATH

## PS3 Saves - BLUS30721

| Icon | Filename | Description |
|------|----------|-------------|
| ![ASURA'S WRATH](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed game, unlocked all gauges and missions |
| ![ASURA'S WRATH](ICON0.PNG) | [00001392.zip](00001392.zip){: .btn .btn-purple } | Asura's Wrath 100% Complete S Rank on every level Hard & Normal plus DLC. |
