---
layout: default
title: "Syndicate"
parent: PS3 Saves
permalink: PS3/BLUS30804/
---
# Syndicate

## PS3 Saves - BLUS30804

| Icon | Filename | Description |
|------|----------|-------------|
| ![Syndicate](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Story Mode Completed+Trophy Popper Save |
