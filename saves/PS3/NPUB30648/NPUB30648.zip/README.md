---
layout: default
title: "RESIDENT EVIL THE DARKSIDE CHRONICLES"
parent: PS3 Saves
permalink: PS3/NPUB30648/
---
# RESIDENT EVIL THE DARKSIDE CHRONICLES

## PS3 Saves - NPUB30648

| Icon | Filename | Description |
|------|----------|-------------|
| ![RESIDENT EVIL THE DARKSIDE CHRONICLES](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, most weapons unlocked and fully upgraded |
