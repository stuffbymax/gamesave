---
layout: default
title: "Darksiders"
parent: PS3 Saves
permalink: PS3/BLES00705/
---
# Darksiders

## PS3 Saves - BLES00705

| Icon | Filename | Description |
|------|----------|-------------|
| ![Darksiders](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Game Completed on Apocalyptic+Trophy Popper Save |
| ![Darksiders](ICON0.PNG) | [00100241.zip](00100241.zip){: .btn .btn-purple } | started save on infernal, all cheat codes applied |
