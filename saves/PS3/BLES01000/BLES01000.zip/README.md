---
layout: default
title: "Racket Sports"
parent: PS3 Saves
permalink: PS3/BLES01000/
---
# Racket Sports

## PS3 Saves - BLES01000

| Icon | Filename | Description |
|------|----------|-------------|
| ![Racket Sports](ICON0.PNG) | [00000133.zip](00000133.zip){: .btn .btn-purple } | Squash Legend |
| ![Racket Sports](ICON0.PNG) | [00000404.zip](00000404.zip){: .btn .btn-purple } | Badminton Legend |
| ![Racket Sports](ICON0.PNG) | [00001551.zip](00001551.zip){: .btn .btn-purple } | Beach Tennis Legend |
| ![Racket Sports](ICON0.PNG) | [00001707.zip](00001707.zip){: .btn .btn-purple } | Table Tennis Legend |
