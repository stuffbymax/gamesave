---
layout: default
title: "Hitman: Absolution"
parent: PS3 Saves
permalink: PS3/BLUS30835/
---
# Hitman: Absolution

## PS3 Saves - BLUS30835

| Icon | Filename | Description |
|------|----------|-------------|
| ![Hitman: Absolution](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% Story Mode Completed Save |
