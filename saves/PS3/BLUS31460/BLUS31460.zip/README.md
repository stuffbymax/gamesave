---
layout: default
title: "Kingdom Hearts HD 2.5 ReMIX"
parent: PS3 Saves
permalink: PS3/BLUS31460/
---
# Kingdom Hearts HD 2.5 ReMIX

## PS3 Saves - BLUS31460

| Icon | Filename | Description |
|------|----------|-------------|
| ![Kingdom Hearts HD 2.5 ReMIX](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | KH2FM 100% Complete, lvl 99 on each character. All keyblades and everything unlocked |
| ![Kingdom Hearts HD 2.5 ReMIX](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | Birth By Sleep lvl 99, all items, Ventus maxed out, all keyblades including ultima weapon |
| ![Kingdom Hearts HD 2.5 ReMIX](ICON0.PNG) | [00000003.zip](00000003.zip){: .btn .btn-purple } | KH2FM: LV99. All Keyblades. All secret bosses defeated. All gummi ship blueprints. 100% of Jiminy's Journal. |
