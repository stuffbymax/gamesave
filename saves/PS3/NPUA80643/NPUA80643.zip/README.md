---
layout: default
title: "Ratchet & Clank"
parent: PS3 Saves
permalink: PS3/NPUA80643/
---
# Ratchet & Clank

## PS3 Saves - NPUA80643

| Icon | Filename | Description |
|------|----------|-------------|
| ![Ratchet & Clank](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Game is fully completed and started the new Challange Mode with all weapons and about 20,000 bolts. |
