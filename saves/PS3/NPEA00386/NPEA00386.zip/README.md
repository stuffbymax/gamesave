---
layout: default
title: "Ratchet & Clank: Going Commando"
parent: PS3 Saves
permalink: PS3/NPEA00386/
---
# Ratchet & Clank: Going Commando

## PS3 Saves - NPEA00386

| Icon | Filename | Description |
|------|----------|-------------|
| ![Ratchet & Clank: Going Commando](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Game is fully completed and started the new Challange Mode with all weapons and 46,000,000 Bolts. |
