---
layout: default
title: "Digimon All-Star Rumble"
parent: PS3 Saves
permalink: PS3/BLUS31441/
---
# Digimon All-Star Rumble

## PS3 Saves - BLUS31441

| Icon | Filename | Description |
|------|----------|-------------|
| ![Digimon All-Star Rumble](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | All Cards Unlocked + Max Bits + Trophy Popper Save |
