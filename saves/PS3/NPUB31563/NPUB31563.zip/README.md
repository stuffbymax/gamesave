---
layout: default
title: "Persona 4 Arena Ultimax"
parent: PS3 Saves
permalink: PS3/NPUB31563/
---
# Persona 4 Arena Ultimax

## PS3 Saves - NPUB31563

| Icon | Filename | Description |
|------|----------|-------------|
| ![Persona 4 Arena Ultimax](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | platinum save, 300 challenges, 3 Golden arenas, Story P4 100% P3 99% Adachi 100% |
