---
layout: default
title: "DuckTales: Remastered"
parent: PS3 Saves
permalink: PS3/NPUB31126/
---
# DuckTales: Remastered

## PS3 Saves - NPUB31126

| Icon | Filename | Description |
|------|----------|-------------|
| ![DuckTales: Remastered](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Max Money Save + Extra Unlocked |
