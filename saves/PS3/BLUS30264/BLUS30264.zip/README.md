---
layout: default
title: "Afro Samurai"
parent: PS3 Saves
permalink: PS3/BLUS30264/
---
# Afro Samurai

## PS3 Saves - BLUS30264

| Icon | Filename | Description |
|------|----------|-------------|
| ![Afro Samurai](ICON0.PNG) | [00232036.zip](00232036.zip){: .btn .btn-purple } | All Treasures Unlocked |
