---
layout: default
title: "FINAL FANTASY XIII-2"
parent: PS3 Saves
permalink: PS3/BLUS30776/
---
# FINAL FANTASY XIII-2

## PS3 Saves - BLUS30776

| Icon | Filename | Description |
|------|----------|-------------|
| ![FINAL FANTASY XIII-2](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Ultimate start game with max gil, CP, materials, monster upgrade items and all fragment skills unlocked |
| ![FINAL FANTASY XIII-2](ICON0.PNG) | [00141959.zip](00141959.zip){: .btn .btn-purple } | THIS SAVE MIGHT REQUIRE ALL DLC - 160/160 Fragments - Max Crystarium (Noel uber STR but crap MAG; Serah uber MAG but crap STR) - Post Game - Both ATB +50 weapons - Both Chain Bonus LV. 5 weapons - Only the best accessories - Best Tamed Monsters |
