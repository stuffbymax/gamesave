---
layout: default
title: "Minecraft: PlayStation 3 Edition"
parent: PS3 Saves
permalink: PS3/NPUB31419/
---
# Minecraft: PlayStation 3 Edition

## PS3 Saves - NPUB31419

| Icon | Filename | Description |
|------|----------|-------------|
| ![Minecraft: PlayStation 3 Edition](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Platinum save for Digital version. Awesome! |
