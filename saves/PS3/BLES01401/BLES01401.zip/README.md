---
layout: default
title: "Dragon Ball Z: Ultimate Tenkaichi"
parent: PS3 Saves
permalink: PS3/BLES01401/
---
# Dragon Ball Z: Ultimate Tenkaichi

## PS3 Saves - BLES01401

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dragon Ball Z: Ultimate Tenkaichi](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | All Characters Unlocked, Movies 88% Completed, Trophy Popper Save |
