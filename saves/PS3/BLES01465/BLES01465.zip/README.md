---
layout: default
title: "RESIDENT EVIL 6"
parent: PS3 Saves
permalink: PS3/BLES01465/
---
# RESIDENT EVIL 6

## PS3 Saves - BLES01465

| Icon | Filename | Description |
|------|----------|-------------|
| ![RESIDENT EVIL 6](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | all weapons upgraded, all abilites unlocked, all levels completed |
| ![RESIDENT EVIL 6](ICON0.PNG) | [00120612.zip](00120612.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Infinite ammo/no reload for every weapon - Infinite health bars - Infinite Skill points - Infinite Stamina - Shoot 1 emblem to get them all - Play in any difficulty and still get the "Leave It to the Pro" trophy. |
| ![RESIDENT EVIL 6](ICON0.PNG) | [00150149.zip](00150149.zip){: .btn .btn-purple } | Ultimate Save : Max Skill Points, All Weapons, All levels of difficulty to rank S, All Emblems, All Medals Story, All Medals Merc Mode, Hidden Skill Training, All Costumes for Merc Mode and all bonus material. |
| ![RESIDENT EVIL 6](ICON0.PNG) | [00073602.zip](00073602.zip){: .btn .btn-purple } | Merc Mode Infinite Ammo - Go to merc settings and use skill set 8. Works with the latest update. |
