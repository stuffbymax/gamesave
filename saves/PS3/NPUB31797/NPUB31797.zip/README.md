---
layout: default
title: "ARSLAN: THE WARRIORS OF LEGEND"
parent: PS3 Saves
permalink: PS3/NPUB31797/
---
# ARSLAN: THE WARRIORS OF LEGEND

## PS3 Saves - NPUB31797

| Icon | Filename | Description |
|------|----------|-------------|
| ![ARSLAN: THE WARRIORS OF LEGEND](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed savegame, all characters max level |
