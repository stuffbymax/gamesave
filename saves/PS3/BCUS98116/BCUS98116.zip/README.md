---
layout: default
title: "Killzone 2"
parent: PS3 Saves
permalink: PS3/BCUS98116/
---
# Killzone 2

## PS3 Saves - BCUS98116

| Icon | Filename | Description |
|------|----------|-------------|
| ![Killzone 2](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Game is 100% Completed. Most Intel collectibles and emblems have Not been collected. |
