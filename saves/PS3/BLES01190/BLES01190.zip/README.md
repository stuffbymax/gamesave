---
layout: default
title: "Dead Space™ 2"
parent: PS3 Saves
permalink: PS3/BLES01190/
---
# Dead Space™ 2

## PS3 Saves - BLES01190

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dead Space™ 2](ICON0.PNG) | [00100724.zip](00100724.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Max Credits - Max Nodes - Max Stasis - Max Health - Max Armour - Max Items. |
| ![Dead Space™ 2](ICON0.PNG) | [00112000.zip](00112000.zip){: .btn .btn-purple } | final fight max difficulty |
