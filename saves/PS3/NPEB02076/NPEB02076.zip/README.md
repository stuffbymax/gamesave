---
layout: default
title: "Resident Evil HD Remaster"
parent: PS3 Saves
permalink: PS3/NPEB02076/
---
# Resident Evil HD Remaster

## PS3 Saves - NPEB02076

| Icon | Filename | Description |
|------|----------|-------------|
| ![Resident Evil HD Remaster](ICON0.PNG) | [00020760.zip](00020760.zip){: .btn .btn-purple } | Save for Only knife trophy |
