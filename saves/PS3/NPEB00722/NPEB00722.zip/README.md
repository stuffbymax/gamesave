---
layout: default
title: "Rocketbirds - Hardboiled Chicken"
parent: PS3 Saves
permalink: PS3/NPEB00722/
---
# Rocketbirds - Hardboiled Chicken

## PS3 Saves - NPEB00722

| Icon | Filename | Description |
|------|----------|-------------|
| ![Rocketbirds - Hardboiled Chicken](ICON0.PNG) | [00062231.zip](00062231.zip){: .btn .btn-purple } | Platinum Save |
