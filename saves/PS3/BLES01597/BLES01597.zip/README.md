---
layout: default
title: "Darksiders II"
parent: PS3 Saves
permalink: PS3/BLES01597/
---
# Darksiders II

## PS3 Saves - BLES01597

| Icon | Filename | Description |
|------|----------|-------------|
| ![Darksiders II](ICON0.PNG) | [00095053.zip](00095053.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Max Gilt - Max Boatman Coins - Max Health Potions - Max Wrath Potions - Max Skill Points - Level Up |
