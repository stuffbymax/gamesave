---
layout: default
title: "Batman: Arkham Asylum"
parent: PS3 Saves
permalink: PS3/BLUS30279/
---
# Batman: Arkham Asylum

## PS3 Saves - BLUS30279

| Icon | Filename | Description |
|------|----------|-------------|
| ![Batman: Arkham Asylum](ICON0.PNG) | [00000916.zip](00000916.zip){: .btn .btn-purple } | 100% Normal mode |
| ![Batman: Arkham Asylum](ICON0.PNG) | [00000917.zip](00000917.zip){: .btn .btn-purple } | 96% complete, 75% Challenges, 240/240 Riddler, 20/20 Upgrades, 42/42 Bios. |
