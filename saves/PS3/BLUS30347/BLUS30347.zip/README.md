---
layout: default
title: "Call of Juarez: Bound in Blood"
parent: PS3 Saves
permalink: PS3/BLUS30347/
---
# Call of Juarez: Bound in Blood

## PS3 Saves - BLUS30347

| Icon | Filename | Description |
|------|----------|-------------|
| ![Call of Juarez: Bound in Blood](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | (Profile) god mode, magic ammo, all guns. |
| ![Call of Juarez: Bound in Blood](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | (Story) god mode, magic ammo, all guns. Beginning on the first level |
