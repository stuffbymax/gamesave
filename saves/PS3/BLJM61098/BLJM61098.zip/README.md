---
layout: default
title: "Phantom Breaker: Extra"
parent: PS3 Saves
permalink: PS3/BLJM61098/
---
# Phantom Breaker: Extra

## PS3 Saves - BLJM61098

| Icon | Filename | Description |
|------|----------|-------------|
| ![Phantom Breaker: Extra](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Situation Battle Mode completed, all 4 unlockable characters (White Mikoto, Rimi, L, Kurisu) unlocked. (1.03) |
