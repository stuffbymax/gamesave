---
layout: default
title: "Dead Space™"
parent: PS3 Saves
permalink: PS3/BLES00310/
---
# Dead Space™

## PS3 Saves - BLES00310

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dead Space™](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | all weapons fully maxed out, new game plus available |
| ![Dead Space™](ICON0.PNG) | [00091707.zip](00091707.zip){: .btn .btn-purple } | 100% save |
