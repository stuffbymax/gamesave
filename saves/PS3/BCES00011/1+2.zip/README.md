---
layout: default
title: "SingStar"
parent: PS3 Saves
permalink: PS3/BCES00011/
---
# SingStar

## PS3 Saves - BCES00011

| Icon | Filename | Description |
|------|----------|-------------|
| ![SingStar](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Singstar Platinum + Dance |
| ![SingStar](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | Singstar Platinum + Guitar |
