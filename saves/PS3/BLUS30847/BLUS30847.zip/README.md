---
layout: default
title: "METAL GEAR SOLID 2/3"
parent: PS3 Saves
permalink: PS3/BLUS30847/
---
# METAL GEAR SOLID 2/3

## PS3 Saves - BLUS30847

| Icon | Filename | Description |
|------|----------|-------------|
| ![METAL GEAR SOLID 2/3](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | MGS3 - 100% completed save includes bandana and stealth |
| ![METAL GEAR SOLID 2/3](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | MGS2 - 100% completed save includes bandana and stealth |
