---
layout: default
title: "Ratchet & Clank: Up Your Arsenal"
parent: PS3 Saves
permalink: PS3/NPEA00387/
---
# Ratchet & Clank: Up Your Arsenal

## PS3 Saves - NPEA00387

| Icon | Filename | Description |
|------|----------|-------------|
| ![Ratchet & Clank: Up Your Arsenal](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | The game is fully completed and started the new Challange Mode with most weapons unlocked and over 450,000 Bolts in the inventory. |
