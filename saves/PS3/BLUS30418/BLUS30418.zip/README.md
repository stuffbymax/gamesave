---
layout: default
title: "Red Dead Redemption"
parent: PS3 Saves
permalink: PS3/BLUS30418/
---
# Red Dead Redemption

## PS3 Saves - BLUS30418

| Icon | Filename | Description |
|------|----------|-------------|
| ![Red Dead Redemption](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Undead Nightmare - All Story Missions & Survivor Side-missions 100% Completed |
| ![Red Dead Redemption](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | All Story Missions 100% Completed. Stranger Side Missions & Outlaws to the End DLC have NOT been Completed |
