---
layout: default
title: "Saints Row - The Third"
parent: PS3 Saves
permalink: PS3/BLUS31062/
---
# Saints Row - The Third

## PS3 Saves - BLUS31062

| Icon | Filename | Description |
|------|----------|-------------|
| ![Saints Row - The Third](ICON0.PNG) | [00120908.zip](00120908.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Max Health - Max Sprint - 16 Million Dollars. |
