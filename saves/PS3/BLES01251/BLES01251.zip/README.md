---
layout: default
title: "Kingdoms of Amalur - Reckoning"
parent: PS3 Saves
permalink: PS3/BLES01251/
---
# Kingdoms of Amalur - Reckoning

## PS3 Saves - BLES01251

| Icon | Filename | Description |
|------|----------|-------------|
| ![Kingdoms of Amalur - Reckoning](ICON0.PNG) | [00105908.zip](00105908.zip){: .btn .btn-purple } | Max Money and Max Exp. For Exp - when you kill enemy you level up 1 not 40. |
