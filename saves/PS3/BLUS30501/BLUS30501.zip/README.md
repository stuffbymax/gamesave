---
layout: default
title: "Dishonored"
parent: PS3 Saves
permalink: PS3/BLUS30501/
---
# Dishonored

## PS3 Saves - BLUS30501

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dishonored](ICON0.PNG) | [00102440.zip](00102440.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: All Powers - 60000 Coins. |
