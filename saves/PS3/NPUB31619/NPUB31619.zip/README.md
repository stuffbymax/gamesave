---
layout: default
title: "Dragon Ball Xenoverse"
parent: PS3 Saves
permalink: PS3/NPUB31619/
---
# Dragon Ball Xenoverse

## PS3 Saves - NPUB31619

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dragon Ball Xenoverse](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Story Mode, Complete DLC, Almost All Items, Character LV 99 |
