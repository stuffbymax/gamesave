---
layout: default
title: "Lollipop Chainsaw"
parent: PS3 Saves
permalink: PS3/BLES01525/
---
# Lollipop Chainsaw

## PS3 Saves - BLES01525

| Icon | Filename | Description |
|------|----------|-------------|
| ![Lollipop Chainsaw](ICON0.PNG) | [00023646.zip](00023646.zip){: .btn .btn-purple } | 100% Unlocked |
| ![Lollipop Chainsaw](ICON0.PNG) | [00025709.zip](00025709.zip){: .btn .btn-purple } | All Upgrades Complete. |
