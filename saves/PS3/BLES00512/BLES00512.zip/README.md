---
layout: default
title: "Mini Ninjas"
parent: PS3 Saves
permalink: PS3/BLES00512/
---
# Mini Ninjas

## PS3 Saves - BLES00512

| Icon | Filename | Description |
|------|----------|-------------|
| ![Mini Ninjas](ICON0.PNG) | [00172751.zip](00172751.zip){: .btn .btn-purple } | platinum save |
| ![Mini Ninjas](ICON0.PNG) | [00174239.zip](00174239.zip){: .btn .btn-purple } | starter save, all flower, lvl max, all chapter unlock, 16millions |
