---
layout: default
title: "DARK VOID"
parent: PS3 Saves
permalink: PS3/BLES00723/
---
# DARK VOID

## PS3 Saves - BLES00723

| Icon | Filename | Description |
|------|----------|-------------|
| ![DARK VOID](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 75% of weapons upgraded, new game plus available (profile savedata) |
| ![DARK VOID](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | 75% of weapons upgraded, new game plus available |
