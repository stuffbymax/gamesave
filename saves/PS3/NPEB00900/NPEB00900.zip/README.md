---
layout: default
title: "Okami HD"
parent: PS3 Saves
permalink: PS3/NPEB00900/
---
# Okami HD

## PS3 Saves - NPEB00900

| Icon | Filename | Description |
|------|----------|-------------|
| ![Okami HD](ICON0.PNG) | [00061926.zip](00061926.zip){: .btn .btn-purple } | Platinum Save |
