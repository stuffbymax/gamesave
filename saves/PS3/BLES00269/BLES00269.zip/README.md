---
layout: default
title: "[PROTOTYPE]™"
parent: PS3 Saves
permalink: PS3/BLES00269/
---
# [PROTOTYPE]™

## PS3 Saves - BLES00269

| Icon | Filename | Description |
|------|----------|-------------|
| ![[PROTOTYPE]™](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | story mode completed 100%, new game plus available, all abilities enabled and fully upgraded |
