---
layout: default
title: "X-Men Origins Wolverine"
parent: PS3 Saves
permalink: PS3/BLUS30268/
---
# X-Men Origins Wolverine

## PS3 Saves - BLUS30268

| Icon | Filename | Description |
|------|----------|-------------|
| ![X-Men Origins Wolverine](ICON0.PNG) | [00000826.zip](00000826.zip){: .btn .btn-purple } | 100% Beaten-Hard |
| ![X-Men Origins Wolverine](ICON0.PNG) | [00001246.zip](00001246.zip){: .btn .btn-purple } | 100% Complete Everything Unlocked Beaten 100% On Easy Normal And Hard |
