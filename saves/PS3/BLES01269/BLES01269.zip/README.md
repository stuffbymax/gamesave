---
layout: default
title: "FINAL FANTASY XIII-2"
parent: PS3 Saves
permalink: PS3/BLES01269/
---
# FINAL FANTASY XIII-2

## PS3 Saves - BLES01269

| Icon | Filename | Description |
|------|----------|-------------|
| ![FINAL FANTASY XIII-2](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Max stats and cp near start of game. |
