---
layout: default
title: "Sonic & All Stars Racing Transformed"
parent: PS3 Saves
permalink: PS3/BLES01646/
---
# Sonic & All Stars Racing Transformed

## PS3 Saves - BLES01646

| Icon | Filename | Description |
|------|----------|-------------|
| ![Sonic & All Stars Racing Transformed](ICON0.PNG) | [00173728.zip](00173728.zip){: .btn .btn-purple } | platinum save |
