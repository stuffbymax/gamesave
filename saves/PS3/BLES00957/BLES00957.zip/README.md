---
layout: default
title: "Rapala Pro Bass Fishing"
parent: PS3 Saves
permalink: PS3/BLES00957/
---
# Rapala Pro Bass Fishing

## PS3 Saves - BLES00957

| Icon | Filename | Description |
|------|----------|-------------|
| ![Rapala Pro Bass Fishing](ICON0.PNG) | [00232937.zip](00232937.zip){: .btn .btn-purple } | Fashionista trophy |
| ![Rapala Pro Bass Fishing](ICON0.PNG) | [00233029.zip](00233029.zip){: .btn .btn-purple } | Seeing Spots trophy |
