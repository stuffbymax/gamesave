---
layout: default
title: "RESIDENT EVIL REVELATIONS 2"
parent: PS3 Saves
permalink: PS3/BLUS31444/
---
# RESIDENT EVIL REVELATIONS 2

## PS3 Saves - BLUS31444

| Icon | Filename | Description |
|------|----------|-------------|
| ![RESIDENT EVIL REVELATIONS 2](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed |
| ![RESIDENT EVIL REVELATIONS 2](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | Unlimited Rocket launcher |
