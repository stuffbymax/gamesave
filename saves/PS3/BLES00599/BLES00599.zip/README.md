---
layout: default
title: "Bayonetta"
parent: PS3 Saves
permalink: PS3/BLES00599/
---
# Bayonetta

## PS3 Saves - BLES00599

| Icon | Filename | Description |
|------|----------|-------------|
| ![Bayonetta](ICON0.PNG) | [00001309.zip](00001309.zip){: .btn .btn-purple } | 82% complete (system save) |
| ![Bayonetta](ICON0.PNG) | [00001310.zip](00001310.zip){: .btn .btn-purple } | 82% complete (user save 0) |
| ![Bayonetta](ICON0.PNG) | [00001311.zip](00001311.zip){: .btn .btn-purple } | 82% complete (user save 1) |
| ![Bayonetta](ICON0.PNG) | [00001312.zip](00001312.zip){: .btn .btn-purple } | 82% complete (user save 2) |
| ![Bayonetta](ICON0.PNG) | [00001313.zip](00001313.zip){: .btn .btn-purple } | 82% complete (user save 3) |
| ![Bayonetta](ICON0.PNG) | [00001314.zip](00001314.zip){: .btn .btn-purple } | 82% complete (continue save) |
| ![Bayonetta](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | all weapons leveled up and unlocked, 100% completed |
| ![Bayonetta](ICON0.PNG) | [00174637.zip](00174637.zip){: .btn .btn-purple } | instant platinum |
