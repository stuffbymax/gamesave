---
layout: default
title: "Soul Calibur V"
parent: PS3 Saves
permalink: PS3/BLUS30736/
---
# Soul Calibur V

## PS3 Saves - BLUS30736

| Icon | Filename | Description |
|------|----------|-------------|
| ![Soul Calibur V](ICON0.PNG) | [00032557.zip](00032557.zip){: .btn .btn-purple } | 100% Completed. Player Level 99. |
| ![Soul Calibur V](ICON0.PNG) | [00075043.zip](00075043.zip){: .btn .btn-purple } | With this save you can use Siegfried SC4 outfit, Nightmare SC4 outfit and Cervantes in Soul Edge form. (May Require DLC) |
