---
layout: default
title: "inFAMOUS: Festival of Blood"
parent: PS3 Saves
permalink: PS3/NPUA80657/
---
# inFAMOUS: Festival of Blood

## PS3 Saves - NPUA80657

| Icon | Filename | Description |
|------|----------|-------------|
| ![inFAMOUS: Festival of Blood](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Game completed 100% except online operations |
