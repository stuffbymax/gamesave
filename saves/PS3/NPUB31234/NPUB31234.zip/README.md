---
layout: default
title: "Dynasty Warriors 8"
parent: PS3 Saves
permalink: PS3/NPUB31234/
---
# Dynasty Warriors 8

## PS3 Saves - NPUB31234

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dynasty Warriors 8](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Max Money, All Characters Level 50, Max Stats |
