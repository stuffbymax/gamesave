---
layout: default
title: "Terminator Salvation"
parent: PS3 Saves
permalink: PS3/BLES00537/
---
# Terminator Salvation

## PS3 Saves - BLES00537

| Icon | Filename | Description |
|------|----------|-------------|
| ![Terminator Salvation](ICON0.PNG) | [00230228.zip](00230228.zip){: .btn .btn-purple } | 100% Completed on Hard. Difficulty trophies. Last checkpoint before the end. Just run to the exit. Chapter-specific trophies should be completed separately. |
