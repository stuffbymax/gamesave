---
layout: default
title: "Black Knight Sword"
parent: PS3 Saves
permalink: PS3/NPUB30719/
---
# Black Knight Sword

## PS3 Saves - NPUB30719

| Icon | Filename | Description |
|------|----------|-------------|
| ![Black Knight Sword](ICON0.PNG) | [00041840.zip](00041840.zip){: .btn .btn-purple } | New Game+ and Full Health Upgrade. |
