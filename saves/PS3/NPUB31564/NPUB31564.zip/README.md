---
layout: default
title: "Samurai Warriors 4"
parent: PS3 Saves
permalink: PS3/NPUB31564/
---
# Samurai Warriors 4

## PS3 Saves - NPUB31564

| Icon | Filename | Description |
|------|----------|-------------|
| ![Samurai Warriors 4](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Story Mode Completed + Max & Level Money + Rare Items Save |
