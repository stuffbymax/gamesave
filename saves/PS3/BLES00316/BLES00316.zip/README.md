---
layout: default
title: "BioShock"
parent: PS3 Saves
permalink: PS3/BLES00316/
---
# BioShock

## PS3 Saves - BLES00316

| Icon | Filename | Description |
|------|----------|-------------|
| ![BioShock](ICON0.PNG) | [00000878.zip](00000878.zip){: .btn .btn-purple } | Story Complete, All Little Sisters Rescued. |
