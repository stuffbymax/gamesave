---
layout: default
title: "METAL GEAR SOLID V: Ground Zeroes"
parent: PS3 Saves
permalink: PS3/NPEB01889/
---
# METAL GEAR SOLID V: Ground Zeroes

## PS3 Saves - NPEB01889

| Icon | Filename | Description |
|------|----------|-------------|
| ![METAL GEAR SOLID V: Ground Zeroes](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Game 100% completed |
