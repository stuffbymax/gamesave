---
layout: default
title: "Gundam Musou"
parent: PS3 Saves
permalink: PS3/BLJM60018/
---
# Gundam Musou

## PS3 Saves - BLJM60018

| Icon | Filename | Description |
|------|----------|-------------|
| ![Gundam Musou](ICON0.PNG) | [00015808.zip](00015808.zip){: .btn .btn-purple } | All mobile suits include warrior gundam and plugin unlocked, and all pilots reach Lv 30. |
