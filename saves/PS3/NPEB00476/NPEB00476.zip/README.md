---
layout: default
title: "I Am Alive"
parent: PS3 Saves
permalink: PS3/NPEB00476/
---
# I Am Alive

## PS3 Saves - NPEB00476

| Icon | Filename | Description |
|------|----------|-------------|
| ![I Am Alive](ICON0.PNG) | [00232712.zip](00232712.zip){: .btn .btn-purple } | Start of game on hard mode with 9999 Retries, 9999 Ammo and 99 Items. |
