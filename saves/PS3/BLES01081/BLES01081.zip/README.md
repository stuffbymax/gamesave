---
layout: default
title: "YAKUZA 4"
parent: PS3 Saves
permalink: PS3/BLES01081/
---
# YAKUZA 4

## PS3 Saves - BLES01081

| Icon | Filename | Description |
|------|----------|-------------|
| ![YAKUZA 4](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Complete Clear Data (Hard) |
| ![YAKUZA 4](ICON0.PNG) | [00123701.zip](00123701.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Max Money - Max Abilities. |
