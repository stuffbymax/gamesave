---
layout: default
title: "Assassin's Creed"
parent: PS3 Saves
permalink: PS3/BLUS30089/
---
# Assassin's Creed

## PS3 Saves - BLUS30089

| Icon | Filename | Description |
|------|----------|-------------|
| ![Assassin's Creed](ICON0.PNG) | [00018058.zip](00018058.zip){: .btn .btn-purple } | game beaten, flags and templars not all killed and collected, eagle vision usable without full synchronosation and innocents can be killed without penalty |
| ![Assassin's Creed](ICON0.PNG) | [00016439.zip](00016439.zip){: .btn .btn-purple } | Saved after the credits, 100% Complete. All objectives cleared, all flags obtained and all Templars killed. Full access to replay the game with no innocent killing limit. |
