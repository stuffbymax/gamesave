---
layout: default
title: "Bayonetta"
parent: PS3 Saves
permalink: PS3/BLUS30367/
---
# Bayonetta

## PS3 Saves - BLUS30367

| Icon | Filename | Description |
|------|----------|-------------|
| ![Bayonetta](ICON0.PNG) | [00053900.zip](00053900.zip){: .btn .btn-purple } | All weapons, items, accessories, and costumes All difficulties/missions unlocked. Copy Protection has already been removed |
| ![Bayonetta](ICON0.PNG) | [00084641.zip](00084641.zip){: .btn .btn-purple } | 100% Completed |
