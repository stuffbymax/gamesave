---
layout: default
title: "SingStar"
parent: PS3 Saves
permalink: PS3/NPEA00374/
---
# SingStar

## PS3 Saves - NPEA00374

| Icon | Filename | Description |
|------|----------|-------------|
| ![SingStar](ICON0.PNG) | [00173403.zip](00173403.zip){: .btn .btn-purple } | platinum save |
