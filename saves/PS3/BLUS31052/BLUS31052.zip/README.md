---
layout: default
title: "Dead Island - Riptide"
parent: PS3 Saves
permalink: PS3/BLUS31052/
---
# Dead Island - Riptide

## PS3 Saves - BLUS31052

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dead Island - Riptide](ICON0.PNG) | [00014959.zip](00014959.zip){: .btn .btn-purple } | All Characters Level 70 Dev M60 Max Cash Max Skills Chapter 1 John on Chapter 2 with some weapons. |
