---
layout: default
title: "Yaiba: Ninja Gaiden Z"
parent: PS3 Saves
permalink: PS3/BLUS31203/
---
# Yaiba: Ninja Gaiden Z

## PS3 Saves - BLUS31203

| Icon | Filename | Description |
|------|----------|-------------|
| ![Yaiba: Ninja Gaiden Z](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Platinum Savegame,all Missions Complete,Level 25. |
