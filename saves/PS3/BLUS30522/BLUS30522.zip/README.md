---
layout: default
title: "Mortal Kombat"
parent: PS3 Saves
permalink: PS3/BLUS30522/
---
# Mortal Kombat

## PS3 Saves - BLUS30522

| Icon | Filename | Description |
|------|----------|-------------|
| ![Mortal Kombat](ICON0.PNG) | [00032750.zip](00032750.zip){: .btn .btn-purple } | Max Krypt Koins Unlock All Characters & Costumes |
