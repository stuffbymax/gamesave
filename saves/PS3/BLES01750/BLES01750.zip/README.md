---
layout: default
title: "METAL GEAR RISING: REVENGEANCE"
parent: PS3 Saves
permalink: PS3/BLES01750/
---
# METAL GEAR RISING: REVENGEANCE

## PS3 Saves - BLES01750

| Icon | Filename | Description |
|------|----------|-------------|
| ![METAL GEAR RISING: REVENGEANCE](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, all upgrades unlocked and swords maxed out |
| ![METAL GEAR RISING: REVENGEANCE](ICON0.PNG) | [00113417.zip](00113417.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Infinite Health - All Weapons - All Skills - Ripper Mode - All Weapons on Max - Max Everything. |
