---
layout: default
title: "BlazBlue: Continuum Shift Extend"
parent: PS3 Saves
permalink: PS3/BLUS30869/
---
# BlazBlue: Continuum Shift Extend

## PS3 Saves - BLUS30869

| Icon | Filename | Description |
|------|----------|-------------|
| ![BlazBlue: Continuum Shift Extend](ICON0.PNG) | [00023588.zip](00023588.zip){: .btn .btn-purple } | Empty profile account. did story mode for the newer characters and arcade mode as well with there ending. |
