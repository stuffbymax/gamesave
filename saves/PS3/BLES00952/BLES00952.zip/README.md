---
layout: default
title: "NARUTO Shippuden: Ultimate Ninja STORM 2"
parent: PS3 Saves
permalink: PS3/BLES00952/
---
# NARUTO Shippuden: Ultimate Ninja STORM 2

## PS3 Saves - BLES00952

| Icon | Filename | Description |
|------|----------|-------------|
| ![NARUTO Shippuden: Ultimate Ninja STORM 2](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed all characters unlocked |
