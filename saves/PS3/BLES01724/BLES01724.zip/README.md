---
layout: default
title: "Fuse™"
parent: PS3 Saves
permalink: PS3/BLES01724/
---
# Fuse™

## PS3 Saves - BLES01724

| Icon | Filename | Description |
|------|----------|-------------|
| ![Fuse™](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, all weapons fully maxed out |
| ![Fuse™](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | All characters are maxed out, it will help you a lot in Co-op |
