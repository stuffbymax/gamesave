---
layout: default
title: "METAL GEAR SOLID V: THE PHANTOM PAIN"
parent: PS3 Saves
permalink: PS3/NPUB31594/
---
# METAL GEAR SOLID V: THE PHANTOM PAIN

## PS3 Saves - NPUB31594

| Icon | Filename | Description |
|------|----------|-------------|
| ![METAL GEAR SOLID V: THE PHANTOM PAIN](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Max Resources + 5 Million Dollars |
