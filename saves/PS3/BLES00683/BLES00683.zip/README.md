---
layout: default
title: "Call of Duty: Modern Warfare 2"
parent: PS3 Saves
permalink: PS3/BLES00683/
---
# Call of Duty: Modern Warfare 2

## PS3 Saves - BLES00683

| Icon | Filename | Description |
|------|----------|-------------|
| ![Call of Duty: Modern Warfare 2](ICON0.PNG) | [00223948.zip](00223948.zip){: .btn .btn-purple } | Has infinate health, laser site, increased melee, all weapons, infinate sprint, infinate ammo an jump really high, This save is locked to single player campaign only..First mission |
