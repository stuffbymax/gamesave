---
layout: default
title: "Fallout 3"
parent: PS3 Saves
permalink: PS3/BLUS30185/
---
# Fallout 3

## PS3 Saves - BLUS30185

| Icon | Filename | Description |
|------|----------|-------------|
| ![Fallout 3](ICON0.PNG) | [00103204.zip](00103204.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Max Skills - Max Caps - Max Stimpaks - Max SPECIAL - Max Bobby-pins - Max Radaway - Max Liberty Bombs. |
