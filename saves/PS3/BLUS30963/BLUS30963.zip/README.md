---
layout: default
title: "LEGO The Lord of the Rings"
parent: PS3 Saves
permalink: PS3/BLUS30963/
---
# LEGO The Lord of the Rings

## PS3 Saves - BLUS30963

| Icon | Filename | Description |
|------|----------|-------------|
| ![LEGO The Lord of the Rings](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% Complete - Over 10 Billion Studs |
| ![LEGO The Lord of the Rings](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | Completed all the Main stories of the Game. Side missions and Collectibles still remain. |
