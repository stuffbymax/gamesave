---
layout: default
title: "The ICO & Shadow of the Colossus Collection"
parent: PS3 Saves
permalink: PS3/BCES01097/
---
# The ICO & Shadow of the Colossus Collection

## PS3 Saves - BCES01097

| Icon | Filename | Description |
|------|----------|-------------|
| ![The ICO & Shadow of the Colossus Collection](ICON0.PNG) | [00025321.zip](00025321.zip){: .btn .btn-purple } | New Game+ 100% Unlock |
