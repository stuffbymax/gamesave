---
layout: default
title: "Dungeon Siege 3"
parent: PS3 Saves
permalink: PS3/BLES01161/
---
# Dungeon Siege 3

## PS3 Saves - BLES01161

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dungeon Siege 3](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Katarina, max money & max exp points, first autosave at the beginning of the game |
