---
layout: default
title: "LEGO Indiana Jones 2: The Adventure Continues"
parent: PS3 Saves
permalink: PS3/BLUS30425/
---
# LEGO Indiana Jones 2: The Adventure Continues

## PS3 Saves - BLUS30425

| Icon | Filename | Description |
|------|----------|-------------|
| ![LEGO Indiana Jones 2: The Adventure Continues](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% complete save |
