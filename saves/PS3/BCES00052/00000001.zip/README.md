---
layout: default
title: "Ratchet & Clank: Tools of destruction"
parent: PS3 Saves
permalink: PS3/BCES00052/
---
# Ratchet & Clank: Tools of destruction

## PS3 Saves - BCES00052

| Icon | Filename | Description |
|------|----------|-------------|
| ![Ratchet & Clank: Tools of destruction](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | everything unlocked, all armor and weapons max upgrades. beginning of challege mode |
