---
layout: default
title: "Dragon Age™: Inquisition"
parent: PS3 Saves
permalink: PS3/BLUS30997/
---
# Dragon Age™: Inquisition

## PS3 Saves - BLUS30997

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dragon Age™: Inquisition](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Starter save with max money |
| ![Dragon Age™: Inquisition](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | Start: 99 Skills point, Characters at Level 25, Some Item are x99, Money at 5,000,0000 |
