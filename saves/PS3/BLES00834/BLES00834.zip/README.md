---
layout: default
title: "YAKUZA 3"
parent: PS3 Saves
permalink: PS3/BLES00834/
---
# YAKUZA 3

## PS3 Saves - BLES00834

| Icon | Filename | Description |
|------|----------|-------------|
| ![YAKUZA 3](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | system data, enables new game plus and 100% gallery and additional options |
| ![YAKUZA 3](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | savedata 100% completed |
