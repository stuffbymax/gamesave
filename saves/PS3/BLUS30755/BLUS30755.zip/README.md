---
layout: default
title: "GoldenEye 007: Reloaded"
parent: PS3 Saves
permalink: PS3/BLUS30755/
---
# GoldenEye 007: Reloaded

## PS3 Saves - BLUS30755

| Icon | Filename | Description |
|------|----------|-------------|
| ![GoldenEye 007: Reloaded](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Game completed on 007 difficulty, all Janus emblems destroyed |
