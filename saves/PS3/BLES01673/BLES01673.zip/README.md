---
layout: default
title: "Injustice - Gods Among Us"
parent: PS3 Saves
permalink: PS3/BLES01673/
---
# Injustice - Gods Among Us

## PS3 Saves - BLES01673

| Icon | Filename | Description |
|------|----------|-------------|
| ![Injustice - Gods Among Us](ICON0.PNG) | [00111924.zip](00111924.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: XP 99,999,999 - Access Cards 999,999 - Armor Keys 999,999 - Trophy for reach level 10 and 100 can be earned after one fight. |
