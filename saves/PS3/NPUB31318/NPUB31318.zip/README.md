---
layout: default
title: "METAL GEAR SOLID V: Ground Zeroes"
parent: PS3 Saves
permalink: PS3/NPUB31318/
---
# METAL GEAR SOLID V: Ground Zeroes

## PS3 Saves - NPUB31318

| Icon | Filename | Description |
|------|----------|-------------|
| ![METAL GEAR SOLID V: Ground Zeroes](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | All tapes, All missions complete, all XOF |
