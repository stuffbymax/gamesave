---
layout: default
title: "Dynasty Warriors: Gundam"
parent: PS3 Saves
permalink: PS3/BLES00147/
---
# Dynasty Warriors: Gundam

## PS3 Saves - BLES00147

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dynasty Warriors: Gundam](ICON0.PNG) | [00019373.zip](00019373.zip){: .btn .btn-purple } | Game 100% Complete with Heero as the main pilot used. |
| ![Dynasty Warriors: Gundam](ICON0.PNG) | [00020863.zip](00020863.zip){: .btn .btn-purple } | All pilot level 30 |
