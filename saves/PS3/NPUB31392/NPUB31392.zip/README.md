---
layout: default
title: "The Evil Within"
parent: PS3 Saves
permalink: PS3/NPUB31392/
---
# The Evil Within

## PS3 Saves - NPUB31392

| Icon | Filename | Description |
|------|----------|-------------|
| ![The Evil Within](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | system data from 100% completed savegame |
| ![The Evil Within](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | 100% completed savegame, all weapons and skills fully upgraded |
| ![The Evil Within](ICON0.PNG) | [00000003.zip](00000003.zip){: .btn .btn-purple } | autosave from 100% completed savegame |
| ![The Evil Within](ICON0.PNG) | [00000004.zip](00000004.zip){: .btn .btn-purple } | The Consequence (DLC) - all collectibles, completed in kurayami mode |
| ![The Evil Within](ICON0.PNG) | [00000005.zip](00000005.zip){: .btn .btn-purple } | The Assignment (DLC) - all collectibles, completed in kurayami mode |
| ![The Evil Within](ICON0.PNG) | [00000006.zip](00000006.zip){: .btn .btn-purple } | The Executioner (DLC) - Game completed 100% |
| ![The Evil Within](ICON0.PNG) | [00000007.zip](00000007.zip){: .btn .btn-purple } | Completed game in akumo, completed in less than five hours, completed without any improvement |
