---
layout: default
title: "Sengoku Musou 4"
parent: PS3 Saves
permalink: PS3/NPJB00534/
---
# Sengoku Musou 4

## PS3 Saves - NPJB00534

| Icon | Filename | Description |
|------|----------|-------------|
| ![Sengoku Musou 4](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% Clear Story Mode, 100 All Armor Costumes, All Characters 100% |
