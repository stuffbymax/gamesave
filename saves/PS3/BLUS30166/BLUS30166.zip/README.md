---
layout: default
title: "BioShock"
parent: PS3 Saves
permalink: PS3/BLUS30166/
---
# BioShock

## PS3 Saves - BLUS30166

| Icon | Filename | Description |
|------|----------|-------------|
| ![BioShock](ICON0.PNG) | [00000786.zip](00000786.zip){: .btn .btn-purple } | Fontaine (Autosave) Survivor difficulty. No Vita-Chambers used. All Little Sisters rescued. Ammo, health, hypos maxed out. |
