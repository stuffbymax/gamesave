---
layout: default
title: "Catherine"
parent: PS3 Saves
permalink: PS3/BLES01459/
---
# Catherine

## PS3 Saves - BLES01459

| Icon | Filename | Description |
|------|----------|-------------|
| ![Catherine](ICON0.PNG) | [00023013.zip](00023013.zip){: .btn .btn-purple } | Platinium Save File. |
| ![Catherine](ICON0.PNG) | [00174327.zip](00174327.zip){: .btn .btn-purple } | platinum save |
