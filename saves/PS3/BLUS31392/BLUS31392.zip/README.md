---
layout: default
title: "LEGO The Hobbit"
parent: PS3 Saves
permalink: PS3/BLUS31392/
---
# LEGO The Hobbit

## PS3 Saves - BLUS31392

| Icon | Filename | Description |
|------|----------|-------------|
| ![LEGO The Hobbit](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 99.4% Complete, Over 10 Billion Studs |
