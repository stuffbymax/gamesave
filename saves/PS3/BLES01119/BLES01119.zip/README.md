---
layout: default
title: "BlazBlue: Continuum Shift"
parent: PS3 Saves
permalink: PS3/BLES01119/
---
# BlazBlue: Continuum Shift

## PS3 Saves - BLES01119

| Icon | Filename | Description |
|------|----------|-------------|
| ![BlazBlue: Continuum Shift](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | platinum save |
