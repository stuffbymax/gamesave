---
layout: default
title: "Resident Evil 4"
parent: PS3 Saves
permalink: PS3/NPEB00342/
---
# Resident Evil 4

## PS3 Saves - NPEB00342

| Icon | Filename | Description |
|------|----------|-------------|
| ![Resident Evil 4](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, all weapons unlocked |
| ![Resident Evil 4](ICON0.PNG) | [00223855.zip](00223855.zip){: .btn .btn-purple } | (SAVE SLOT 1 ONLY) bottle caps unlocked, max HP for Leon an Ada, weapon upgrades unlocked, Times saved 1, max items. |
