---
layout: default
title: "Naruto Shippuden™ Ultimate Ninja Storm 3 Full Burst"
parent: PS3 Saves
permalink: PS3/BLUS31066/
---
# Naruto Shippuden™ Ultimate Ninja Storm 3 Full Burst

## PS3 Saves - BLUS31066

| Icon | Filename | Description |
|------|----------|-------------|
| ![Naruto Shippuden™ Ultimate Ninja Storm 3 Full Burst](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed |
