---
layout: default
title: "Gran Turismo 6"
parent: PS3 Saves
permalink: PS3/BCJS37016/
---
# Gran Turismo 6

## PS3 Saves - BCJS37016

| Icon | Filename | Description |
|------|----------|-------------|
| ![Gran Turismo 6](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | All cars unlocked (+1200 cars) and $50 million credits |
| ![Gran Turismo 6](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | 50.000 Credit bonus and the Honda Fit on the start of the campaign |
| ![Gran Turismo 6](ICON0.PNG) | [00000003.zip](00000003.zip){: .btn .btn-purple } | Game completed 87%, all license test completed in gold except Veyron & Aventador, all racing stars earned, 1270 cars in the garage |
| ![Gran Turismo 6](ICON0.PNG) | [00000004.zip](00000004.zip){: .btn .btn-purple } | GT6 Starter Save with the starter Honda Fit with all parts and 50.000 credits to start the game! |
