---
layout: default
title: "Naruto Shippuden - Ultimate Ninja Storm 2"
parent: PS3 Saves
permalink: PS3/BLUS30495/
---
# Naruto Shippuden - Ultimate Ninja Storm 2

## PS3 Saves - BLUS30495

| Icon | Filename | Description |
|------|----------|-------------|
| ![Naruto Shippuden - Ultimate Ninja Storm 2](ICON0.PNG) | [00113707.zip](00113707.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheat added: Max Ryo. |
