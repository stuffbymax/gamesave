---
layout: default
title: "Fat Princess"
parent: PS3 Saves
permalink: PS3/NPUA80139/
---
# Fat Princess

## PS3 Saves - NPUA80139

| Icon | Filename | Description |
|------|----------|-------------|
| ![Fat Princess](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% Story Mode Completed+Trophy Popper Save |
