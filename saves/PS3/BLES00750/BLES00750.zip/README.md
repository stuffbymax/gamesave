---
layout: default
title: "Sonic & Sega All Stars Racing"
parent: PS3 Saves
permalink: PS3/BLES00750/
---
# Sonic & Sega All Stars Racing

## PS3 Saves - BLES00750

| Icon | Filename | Description |
|------|----------|-------------|
| ![Sonic & Sega All Stars Racing](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% unlocked |
| ![Sonic & Sega All Stars Racing](ICON0.PNG) | [00174914.zip](00174914.zip){: .btn .btn-purple } | instant platinum |
