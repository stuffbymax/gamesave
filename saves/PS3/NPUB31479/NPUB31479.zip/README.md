---
layout: default
title: "ONE PIECE Unlimited World Red"
parent: PS3 Saves
permalink: PS3/NPUB31479/
---
# ONE PIECE Unlimited World Red

## PS3 Saves - NPUB31479

| Icon | Filename | Description |
|------|----------|-------------|
| ![ONE PIECE Unlimited World Red](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, all characters fully upgraded |
