---
layout: default
title: "Deus Ex Human Revolution"
parent: PS3 Saves
permalink: PS3/BLES01150/
---
# Deus Ex Human Revolution

## PS3 Saves - BLES01150

| Icon | Filename | Description |
|------|----------|-------------|
| ![Deus Ex Human Revolution](ICON0.PNG) | [00101938.zip](00101938.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Credits 15999984 - XP 15999984 - Praxis 99. |
