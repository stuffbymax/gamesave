---
layout: default
title: "Dead Space™"
parent: PS3 Saves
permalink: PS3/BLES00308/
---
# Dead Space™

## PS3 Saves - BLES00308

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dead Space™](ICON0.PNG) | [00194043.zip](00194043.zip){: .btn .btn-purple } | Max nodes, credits, health an stasis, suit scematic 6, max items in all slots |
