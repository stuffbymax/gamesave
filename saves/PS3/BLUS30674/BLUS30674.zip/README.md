---
layout: default
title: "Green Lantern - Rise of the Manhunters"
parent: PS3 Saves
permalink: PS3/BLUS30674/
---
# Green Lantern - Rise of the Manhunters

## PS3 Saves - BLUS30674

| Icon | Filename | Description |
|------|----------|-------------|
| ![Green Lantern - Rise of the Manhunters](ICON0.PNG) | [00080130.zip](00080130.zip){: .btn .btn-purple } | 100% Complete Everything Unlocked |
