---
layout: default
title: "BlazBlue: Continuum Shift Extend"
parent: PS3 Saves
permalink: PS3/BLES01487/
---
# BlazBlue: Continuum Shift Extend

## PS3 Saves - BLES01487

| Icon | Filename | Description |
|------|----------|-------------|
| ![BlazBlue: Continuum Shift Extend](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | platinum save |
| ![BlazBlue: Continuum Shift Extend](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | replay theater, view videos for trophy |
