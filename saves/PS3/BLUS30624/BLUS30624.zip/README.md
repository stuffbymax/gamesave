---
layout: default
title: "Dead Space™ 2"
parent: PS3 Saves
permalink: PS3/BLUS30624/
---
# Dead Space™ 2

## PS3 Saves - BLUS30624

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dead Space™ 2](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, weapons max upgraded |
