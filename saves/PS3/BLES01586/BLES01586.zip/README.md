---
layout: default
title: "Of Orcs and Men"
parent: PS3 Saves
permalink: PS3/BLES01586/
---
# Of Orcs and Men

## PS3 Saves - BLES01586

| Icon | Filename | Description |
|------|----------|-------------|
| ![Of Orcs and Men](ICON0.PNG) | [00013529.zip](00013529.zip){: .btn .btn-purple } | Virgin Save[0%]: Level and Skill points Max. Start on Extreme Difficulty. |
| ![Of Orcs and Men](ICON0.PNG) | [00114736.zip](00114736.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Max Level - Max Skill Points. |
