---
layout: default
title: "Tales of Berseria"
parent: PS3 Saves
permalink: PS3/BLJS10330/
---
# Tales of Berseria

## PS3 Saves - BLJS10330

| Icon | Filename | Description |
|------|----------|-------------|
| ![Tales of Berseria](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Velvet Lv. 7, Max Gald coins (Japan version) |
