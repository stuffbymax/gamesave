---
layout: default
title: "Sonic & All Stars Racing Transformed"
parent: PS3 Saves
permalink: PS3/BLUS30839/
---
# Sonic & All Stars Racing Transformed

## PS3 Saves - BLUS30839

| Icon | Filename | Description |
|------|----------|-------------|
| ![Sonic & All Stars Racing Transformed](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Game Completed 100% + Trophy Popper Save |
