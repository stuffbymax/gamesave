---
layout: default
title: "Fallout - New Vegas"
parent: PS3 Saves
permalink: PS3/BLUS30500/
---
# Fallout - New Vegas

## PS3 Saves - BLUS30500

| Icon | Filename | Description |
|------|----------|-------------|
| ![Fallout - New Vegas](ICON0.PNG) | [00021436.zip](00021436.zip){: .btn .btn-purple } | LVL 30-3 MILLION CAPS LOTS OF AMMO AND GUNS |
| ![Fallout - New Vegas](ICON0.PNG) | [00104127.zip](00104127.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: All Keys - All Weapons - All Perks - All items - All Locations Unlocked - Max Out Stats -1 Million+ Caps - 100,000+Health Points/Action Points/Weight Pounds - 100000+Ammo - Debug Pistol. |
