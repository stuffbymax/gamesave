---
layout: default
title: "Madden NFL 13"
parent: PS3 Saves
permalink: PS3/BLUS30973/
---
# Madden NFL 13

## PS3 Saves - BLUS30973

| Icon | Filename | Description |
|------|----------|-------------|
| ![Madden NFL 13](ICON0.PNG) | [00112849.zip](00112849.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Max XP - Max Player Legacy. |
