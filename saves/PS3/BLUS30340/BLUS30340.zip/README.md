---
layout: default
title: "Aliens vs Predator"
parent: PS3 Saves
permalink: PS3/BLUS30340/
---
# Aliens vs Predator

## PS3 Saves - BLUS30340

| Icon | Filename | Description |
|------|----------|-------------|
| ![Aliens vs Predator](ICON0.PNG) | [00001124.zip](00001124.zip){: .btn .btn-purple } | All Storys finished on Normal Mode,56% complete |
| ![Aliens vs Predator](ICON0.PNG) | [00231647.zip](00231647.zip){: .btn .btn-purple } | All Marine, Predator And Alien Missions Unlocked |
