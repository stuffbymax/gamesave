---
layout: default
title: "RESIDENT EVIL 6"
parent: PS3 Saves
permalink: PS3/BLUS30855/
---
# RESIDENT EVIL 6

## PS3 Saves - BLUS30855

| Icon | Filename | Description |
|------|----------|-------------|
| ![RESIDENT EVIL 6](ICON0.PNG) | [00184351.zip](00184351.zip){: .btn .btn-purple } | 500 health pills all characters, Picardo for all characters, max kills, score rank s mercenaries, ammo 999 |
