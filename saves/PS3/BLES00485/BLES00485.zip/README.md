---
layout: default
title: "Resident Evil 5"
parent: PS3 Saves
permalink: PS3/BLES00485/
---
# Resident Evil 5

## PS3 Saves - BLES00485

| Icon | Filename | Description |
|------|----------|-------------|
| ![Resident Evil 5](ICON0.PNG) | [00120115.zip](00120115.zip){: .btn .btn-purple } | Virgin Save[0%]: Cheats added: Max Money - Max Points - Infinite Golden Eggs - Infinite Grenades - Infinite Fire Grenades. |
| ![Resident Evil 5](ICON0.PNG) | [00183847.zip](00183847.zip){: .btn .btn-purple } | items 9999, weapons unlocked an ugraded, health max |
| ![Resident Evil 5](ICON0.PNG) | [00100118.zip](00100118.zip){: .btn .btn-purple } | (RE5 Gold) platinum save |
| ![Resident Evil 5](ICON0.PNG) | [00101637.zip](00101637.zip){: .btn .btn-purple } | (RE5 Gold) starter save, all cheat codes applied |
