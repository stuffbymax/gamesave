---
layout: default
title: "Final Fantasy XIII"
parent: PS3 Saves
permalink: PS3/MRTC00003/
---
# Final Fantasy XIII

## PS3 Saves - MRTC00003

| Icon | Filename | Description |
|------|----------|-------------|
| ![Final Fantasy XIII](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed save |
| ![Final Fantasy XIII](ICON0.PNG) | [00090434.zip](00090434.zip){: .btn .btn-purple } | Max Crystarium - Post Game - Equipment maxed - Specialized setups for each character - Save Slot 00 is in front of the final boss - Save Slot 01 is in front of the super boss, Attacus |
