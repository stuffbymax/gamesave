---
layout: default
title: "Tales of Zestiria"
parent: PS3 Saves
permalink: PS3/BLES02152/
---
# Tales of Zestiria

## PS3 Saves - BLES02152

| Icon | Filename | Description |
|------|----------|-------------|
| ![Tales of Zestiria](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Max HP + Max Level + Max Money Save |
