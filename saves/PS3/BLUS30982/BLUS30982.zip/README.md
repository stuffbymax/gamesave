---
layout: default
title: "Borderlands 2"
parent: PS3 Saves
permalink: PS3/BLUS30982/
---
# Borderlands 2

## PS3 Saves - BLUS30982

| Icon | Filename | Description |
|------|----------|-------------|
| ![Borderlands 2](ICON0.PNG) | [00081345.zip](00081345.zip){: .btn .btn-purple } | Virgin Save[0%]: Max Skill Pionts Max Money Max Eridium Max Seraph Crystals Max Ammo |
| ![Borderlands 2](ICON0.PNG) | [00132736.zip](00132736.zip){: .btn .btn-purple } | Platinum Save |
| ![Borderlands 2](ICON0.PNG) | [00191308.zip](00191308.zip){: .btn .btn-purple } | very begining of game Gaige. Level 50. Hunter's Grotto level 50 mass money crystals respect points weapons |
