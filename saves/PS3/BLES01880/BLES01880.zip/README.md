---
layout: default
title: "FINAL FANTASY X & X-2 HD Remaster"
parent: PS3 Saves
permalink: PS3/BLES01880/
---
# FINAL FANTASY X & X-2 HD Remaster

## PS3 Saves - BLES01880

| Icon | Filename | Description |
|------|----------|-------------|
| ![FINAL FANTASY X & X-2 HD Remaster](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | FF X-2 HD: 100% completed savegame, all grids, all abilities unlocked |
| ![FINAL FANTASY X & X-2 HD Remaster](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | FF X HD: Starter Save. All max stats, all Abilities, all Overdrive, all Items x99 and max money |
