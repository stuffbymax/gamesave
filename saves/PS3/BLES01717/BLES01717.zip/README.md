---
layout: default
title: "Call of Duty®: Black Ops II"
parent: PS3 Saves
permalink: PS3/BLES01717/
---
# Call of Duty®: Black Ops II

## PS3 Saves - BLES01717

| Icon | Filename | Description |
|------|----------|-------------|
| ![Call of Duty®: Black Ops II](ICON0.PNG) | [00000004.zip](00000004.zip){: .btn .btn-purple } | 100% completed game |
