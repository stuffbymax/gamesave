---
layout: default
title: "F1 Race Stars"
parent: PS3 Saves
permalink: PS3/BLES01715/
---
# F1 Race Stars

## PS3 Saves - BLES01715

| Icon | Filename | Description |
|------|----------|-------------|
| ![F1 Race Stars](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% Completed + Instant Platinum Save |
| ![F1 Race Stars](ICON0.PNG) | [00174658.zip](00174658.zip){: .btn .btn-purple } | instant platinum |
