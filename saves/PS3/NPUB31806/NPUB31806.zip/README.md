---
layout: default
title: "Guilty Gear Xrd: Revelator"
parent: PS3 Saves
permalink: PS3/NPUB31806/
---
# Guilty Gear Xrd: Revelator

## PS3 Saves - NPUB31806

| Icon | Filename | Description |
|------|----------|-------------|
| ![Guilty Gear Xrd: Revelator](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | (Story) Max Money + 95% Bonus Characters Colors + Boss Unlocked |
| ![Guilty Gear Xrd: Revelator](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | (System) Max Money + 95% Bonus Characters Colors + Boss Unlocked |
