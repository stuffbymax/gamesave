---
layout: default
title: "Assassin's Creed II"
parent: PS3 Saves
permalink: PS3/BLUS30364/
---
# Assassin's Creed II

## PS3 Saves - BLUS30364

| Icon | Filename | Description |
|------|----------|-------------|
| ![Assassin's Creed II](ICON0.PNG) | [00021822.zip](00021822.zip){: .btn .btn-purple } | 94 feathers and 19 glyphs |
