---
layout: default
title: "Teenage Mutant Ninja Turtles™: Mutants in Manhattan"
parent: PS3 Saves
permalink: PS3/NPEB02246/
---
# Teenage Mutant Ninja Turtles™: Mutants in Manhattan

## PS3 Saves - NPEB02246

| Icon | Filename | Description |
|------|----------|-------------|
| ![Teenage Mutant Ninja Turtles™: Mutants in Manhattan](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, all skills fully upgraded |
