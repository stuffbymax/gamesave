---
layout: default
title: "Kung Fu Panda™"
parent: PS3 Saves
permalink: PS3/BLES00243/
---
# Kung Fu Panda™

## PS3 Saves - BLES00243

| Icon | Filename | Description |
|------|----------|-------------|
| ![Kung Fu Panda™](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | unlock all abilities, new game plus savedata 100% completed (profile savedata) |
| ![Kung Fu Panda™](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | unlock all abilities, new game plus savedata 100% completed savedata |
