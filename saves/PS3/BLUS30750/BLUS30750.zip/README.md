---
layout: default
title: "RESIDENT EVIL™ Operation Raccoon City"
parent: PS3 Saves
permalink: PS3/BLUS30750/
---
# RESIDENT EVIL™ Operation Raccoon City

## PS3 Saves - BLUS30750

| Icon | Filename | Description |
|------|----------|-------------|
| ![RESIDENT EVIL™ Operation Raccoon City](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, all abilities fully upgraded |
