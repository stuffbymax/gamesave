---
layout: default
title: "Lara Croft and the Guardian of Light"
parent: PS3 Saves
permalink: PS3/NPUB30225/
---
# Lara Croft and the Guardian of Light

## PS3 Saves - NPUB30225

| Icon | Filename | Description |
|------|----------|-------------|
| ![Lara Croft and the Guardian of Light](ICON0.PNG) | [00042125.zip](00042125.zip){: .btn .btn-purple } | 100% Complete With New Game+ |
