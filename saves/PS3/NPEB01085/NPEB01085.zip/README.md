---
layout: default
title: "Guardians of Middle Earth"
parent: PS3 Saves
permalink: PS3/NPEB01085/
---
# Guardians of Middle Earth

## PS3 Saves - NPEB01085

| Icon | Filename | Description |
|------|----------|-------------|
| ![Guardians of Middle Earth](ICON0.PNG) | [00172548.zip](00172548.zip){: .btn .btn-purple } | platinum save |
