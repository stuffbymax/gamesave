---
layout: default
title: "Cars: Race-O-Rama"
parent: PS3 Saves
permalink: PS3/BLES00620/
---
# Cars: Race-O-Rama

## PS3 Saves - BLES00620

| Icon | Filename | Description |
|------|----------|-------------|
| ![Cars: Race-O-Rama](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | 100% completed game |
