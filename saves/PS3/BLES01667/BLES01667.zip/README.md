---
layout: default
title: "Assassin's Creed III"
parent: PS3 Saves
permalink: PS3/BLES01667/
---
# Assassin's Creed III

## PS3 Saves - BLES01667

| Icon | Filename | Description |
|------|----------|-------------|
| ![Assassin's Creed III](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Completed Story Mode (100%) + DLCs and 100% synchro and all outfits. |
