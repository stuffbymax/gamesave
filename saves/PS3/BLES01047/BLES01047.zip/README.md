---
layout: default
title: "Castlevania Lords of Shadow™"
parent: PS3 Saves
permalink: PS3/BLES01047/
---
# Castlevania Lords of Shadow™

## PS3 Saves - BLES01047

| Icon | Filename | Description |
|------|----------|-------------|
| ![Castlevania Lords of Shadow™](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, all abilities and upgrades unlocked and maxed out, all levels available to be played |
| ![Castlevania Lords of Shadow™](ICON0.PNG) | [00173226.zip](00173226.zip){: .btn .btn-purple } | platinum save |
