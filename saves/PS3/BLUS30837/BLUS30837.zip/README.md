---
layout: default
title: "LEGO Batman 2: DC Super Heroes"
parent: PS3 Saves
permalink: PS3/BLUS30837/
---
# LEGO Batman 2: DC Super Heroes

## PS3 Saves - BLUS30837

| Icon | Filename | Description |
|------|----------|-------------|
| ![LEGO Batman 2: DC Super Heroes](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% complete save |
