---
layout: default
title: "Guacamelee!"
parent: PS3 Saves
permalink: PS3/NPUB30672/
---
# Guacamelee!

## PS3 Saves - NPUB30672

| Icon | Filename | Description |
|------|----------|-------------|
| ![Guacamelee!](ICON0.PNG) | [00022215.zip](00022215.zip){: .btn .btn-purple } | Start of the game with max power, max health and max mana. |
