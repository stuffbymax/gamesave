---
layout: default
title: "Castlevania Lords of Shadow: Mirror of Fate"
parent: PS3 Saves
permalink: PS3/NPEB01441/
---
# Castlevania Lords of Shadow: Mirror of Fate

## PS3 Saves - NPEB01441

| Icon | Filename | Description |
|------|----------|-------------|
| ![Castlevania Lords of Shadow: Mirror of Fate](ICON0.PNG) | [00023616.zip](00023616.zip){: .btn .btn-purple } | Game Clear Normal 100% Unlocked |
