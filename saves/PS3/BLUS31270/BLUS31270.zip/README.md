---
layout: default
title: "Call of Duty: Ghosts"
parent: PS3 Saves
permalink: PS3/BLUS31270/
---
# Call of Duty: Ghosts

## PS3 Saves - BLUS31270

| Icon | Filename | Description |
|------|----------|-------------|
| ![Call of Duty: Ghosts](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | Campaign completed on Regular. |
