---
layout: default
title: "ONE PIECE: PIRATE WARRIORS 2"
parent: PS3 Saves
permalink: PS3/NPEB01795/
---
# ONE PIECE: PIRATE WARRIORS 2

## PS3 Saves - NPEB01795

| Icon | Filename | Description |
|------|----------|-------------|
| ![ONE PIECE: PIRATE WARRIORS 2](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, unlocked all characters |
