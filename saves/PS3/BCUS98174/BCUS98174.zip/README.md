---
layout: default
title: "The Last of Us"
parent: PS3 Saves
permalink: PS3/BCUS98174/
---
# The Last of Us

## PS3 Saves - BCUS98174

| Icon | Filename | Description |
|------|----------|-------------|
| ![The Last of Us](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | new game plus, unlocked all difficulties and completed game on most difficult game mode |
| ![The Last of Us](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | new game plus, unlocked all difficulties and completed game on most difficult game mode (savedata profile) |
