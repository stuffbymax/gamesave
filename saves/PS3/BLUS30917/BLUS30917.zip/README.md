---
layout: default
title: "Lollipop Chainsaw"
parent: PS3 Saves
permalink: PS3/BLUS30917/
---
# Lollipop Chainsaw

## PS3 Saves - BLUS30917

| Icon | Filename | Description |
|------|----------|-------------|
| ![Lollipop Chainsaw](ICON0.PNG) | [00023775.zip](00023775.zip){: .btn .btn-purple } | All shop items purchased (upgrades, skills, non-DLC costumes, music, concept art), all story chapters and difficulties unlocked, all students rescued. |
| ![Lollipop Chainsaw](ICON0.PNG) | [00092316.zip](00092316.zip){: .btn .btn-purple } | All upgrades - All non-DLC costumes - All story chapters and difficulties unlocked - All students rescued |
