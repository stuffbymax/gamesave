---
layout: default
title: "Gran Turismo 5"
parent: PS3 Saves
permalink: PS3/BCUS98114/
---
# Gran Turismo 5

## PS3 Saves - BCUS98114

| Icon | Filename | Description |
|------|----------|-------------|
| ![Gran Turismo 5](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100.000 Credit bonus, Secret Menu and DLC Content Unlocked |
| ![Gran Turismo 5](ICON0.PNG) | [00022438.zip](00022438.zip){: .btn .btn-purple } | Max Money Max Exp |
