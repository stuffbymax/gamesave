---
layout: default
title: "Tales of Xillia"
parent: PS3 Saves
permalink: PS3/BLES01815/
---
# Tales of Xillia

## PS3 Saves - BLES01815

| Icon | Filename | Description |
|------|----------|-------------|
| ![Tales of Xillia](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | level 200 all characters, new game plus available |
