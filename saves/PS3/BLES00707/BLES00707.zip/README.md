---
layout: default
title: "Wet"
parent: PS3 Saves
permalink: PS3/BLES00707/
---
# Wet

## PS3 Saves - BLES00707

| Icon | Filename | Description |
|------|----------|-------------|
| ![Wet](ICON0.PNG) | [00174445.zip](00174445.zip){: .btn .btn-purple } | platinum save |
