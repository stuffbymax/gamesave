---
layout: default
title: "Dead Rising 2"
parent: PS3 Saves
permalink: PS3/BLES00948/
---
# Dead Rising 2

## PS3 Saves - BLES00948

| Icon | Filename | Description |
|------|----------|-------------|
| ![Dead Rising 2](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | max level reached, new game plus enabled |
