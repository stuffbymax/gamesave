---
layout: default
title: "Alone in the Dark: Inferno"
parent: PS3 Saves
permalink: PS3/BLUS30232/
---
# Alone in the Dark: Inferno

## PS3 Saves - BLUS30232

| Icon | Filename | Description |
|------|----------|-------------|
| ![Alone in the Dark: Inferno](ICON0.PNG) | [00000883.zip](00000883.zip){: .btn .btn-purple } | Game Completed, All Evil Roots Burned |
