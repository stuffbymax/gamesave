---
layout: default
title: "[PROTOTYPE®2]"
parent: PS3 Saves
permalink: PS3/BLES01532/
---
# [PROTOTYPE®2]

## PS3 Saves - BLES01532

| Icon | Filename | Description |
|------|----------|-------------|
| ![[PROTOTYPE®2]](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, all upgraded abilities, new game available |
| ![[PROTOTYPE®2]](ICON0.PNG) | [00000002.zip](00000002.zip){: .btn .btn-purple } | setup and profile savedata info |
