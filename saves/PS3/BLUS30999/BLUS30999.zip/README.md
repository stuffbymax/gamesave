---
layout: default
title: "Castlevania Lords of Shadow 2"
parent: PS3 Saves
permalink: PS3/BLUS30999/
---
# Castlevania Lords of Shadow 2

## PS3 Saves - BLUS30999

| Icon | Filename | Description |
|------|----------|-------------|
| ![Castlevania Lords of Shadow 2](ICON0.PNG) | [00000001.zip](00000001.zip){: .btn .btn-purple } | 100% completed, new game plus available, all abilities fully upgraded |
