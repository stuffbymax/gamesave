---
layout: default
title: "BioShock 2"
parent: PS3 Saves
permalink: PS3/BLUS30420/
---
# BioShock 2

## PS3 Saves - BLUS30420

| Icon | Filename | Description |
|------|----------|-------------|
| ![BioShock 2](ICON0.PNG) | [00001219.zip](00001219.zip){: .btn .btn-purple } | end of game powerful perks and plasmids. |
| ![BioShock 2](ICON0.PNG) | [00001248.zip](00001248.zip){: .btn .btn-purple } | Pauper's drop, hard, little sister collecting adam |
