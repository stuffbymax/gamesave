---
layout: default
title: "Fat Princess"
parent: PS3 Saves
permalink: PS3/NPEA00111/
---
# Fat Princess

## PS3 Saves - NPEA00111

| Icon | Filename | Description |
|------|----------|-------------|
| ![Fat Princess](ICON0.PNG) | [00172503.zip](00172503.zip){: .btn .btn-purple } | platinum save |
